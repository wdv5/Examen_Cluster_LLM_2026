"""Ejecuta y conserva las evidencias crudas de cada celda experimental."""
import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time

CODE = Path(__file__).resolve().parent
CONFIG = json.loads((CODE / "config.json").read_text())
COMPOSE = ["docker", "compose", "-p", "examen-utb", "-f", "docker-compose.yml"]


def run(command, env, check=True, input=None):
    return subprocess.run(command, cwd=CODE, env=env, text=True, input=input,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=check)


def store(directory, name, result):
    (directory / name).write_text(result.stdout)
    if result.stderr:
        (directory / (name + ".stderr")).write_text(result.stderr)


def start_cell(args, name, scenario):
    config = CONFIG[name]
    directory = args.logs / f"{name}-{scenario}"
    directory.mkdir(exist_ok=False, parents=True)
    metrics_path = args.logs / "metricas.jsonl"
    workers = [f"worker-{i}" for i in range(1, config["workers"] + 1)]
    nodes = ["master", *workers]
    env = dict(os.environ, MODEL_PATH=str(args.model), LLAMA_BIN=str(args.bin),
               SCENARIO=scenario, TRANSPORT=args.transport,
               RPC_ENDPOINTS=",".join(f"{worker}:50052" for worker in workers),
               MASTER_GIB=str(args.master_gib), SPLIT=config["split"], CONTEXT=str(config["context"]), KV_TYPE=config["kv"])

    def compose(*command, check=True):
        return run([*COMPOSE, *command], env, check=check)

    def node(service, *command, check=True, input=None):
        return run([*COMPOSE, "exec", "-T", service, *command], env, check=check, input=input)

    begin = time.time()
    try:
        print(f"{name}-{scenario}: arranque", flush=True)
        compose("up", "-d", *workers)
        for worker in workers:
            port = 50053 if args.transport == "proxy" else 50052
            node(worker, "python3", "/lab/esperar_puertos.py", str(port), "50052")
        with args.model.open("rb") as source:
            os.posix_fadvise(source.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
        begin = time.time()
        compose("up", "-d", "master")
        for _ in range(600):
            result = node("master", "curl", "-fsS", "--max-time", "1",
                          "http://127.0.0.1:8080/health", check=False)
            if result.returncode == 0 and json.loads(result.stdout).get("status") == "ok":
                break
            state = compose("ps", "--status", "exited", "--services", check=False)
            if "master" in state.stdout.splitlines():
                raise RuntimeError("master salió antes de /health")
            time.sleep(0.5)
        else:
            raise RuntimeError("Tiempo agotado esperando /health")
        (directory / "inicio.json").write_text(json.dumps({
            "fecha_utc": datetime.now(timezone.utc).isoformat(),
            "segundos_hasta_health": time.time() - begin,
            "cache_so": "POSIX_FADV_DONTNEED sobre el archivo (consultivo)",
            "rpc_en_arranque": "sin emulación" if args.transport == "proxy" else "netem",
            "master_gib": args.master_gib,
            "modelo": args.model.name, "config": config, "escenario": scenario,
        }, indent=2) + "\n")
        store(directory, "health.json", result)
        store(directory, "compose-ps.txt", compose("ps"))
        for service in nodes:
            store(directory, f"{service}-limites.txt", node(service, "sh", "-c",
                  "cat /proc/1/limits; printf '\\nmemory.max: '; cat /sys/fs/cgroup/memory.max"))
        ids = compose("ps", "-q").stdout.split()
        store(directory, "docker-stats.jsonl", run(
            ["docker", "stats", "--no-stream", "--format", "{{json .}}", *ids], env, check=False))
        if args.transport == "proxy":
            for worker in workers:
                node(worker, "touch", "/tmp/emular-red")
        if metrics_path.exists():
            node("master", "tee", "/tmp/metricas.jsonl",
                 input=metrics_path.read_text().splitlines()[-1] + "\n")

        with ExitStack() as stack:
            samplers = []
            for service in nodes:
                trace = stack.enter_context((directory / f"{service}-telemetria.jsonl").open("w"))
                sampler = subprocess.Popen(
                    [*COMPOSE, "exec", "-T", service, "python3", "/lab/telemetry.py"],
                    cwd=CODE, env=env, stdout=trace, stderr=trace,
                )
                samplers.append(sampler)
            try:
                with (directory / "corridas.jsonl").open("w") as events:
                    for repetition in range(args.repeticiones + 1):
                        warm = repetition == 0
                        label = f"{name}-{scenario}-" + ("warmup" if warm else f"r{repetition}")
                        remote_path = "/tmp/warmup.jsonl" if warm else "/tmp/metricas.jsonl"
                        print(f"{label}: solicitud", flush=True)
                        start = time.time()
                        result = node(
                            "master", "python3", "/lab/collect.py", "--label", label,
                            "--n-predict", str(args.tokens), "--prompt-file", "/lab/prompt.txt",
                            "--out", remote_path, "--extra", json.dumps({
                                "scenario": scenario,
                                "config": {"name": name, "repetition": repetition, **config},
                            }), check=False,
                        )
                        end = time.time()
                        store(directory, f"{label}.txt", result)
                        if result.returncode != 0:
                            raise RuntimeError(f"{label}: {result.stderr.strip()}")
                        record = node("master", "tail", "-n", "1", remote_path).stdout
                        json.loads(record)
                        with ((directory / "warmup.jsonl") if warm else metrics_path).open("a") as out:
                            out.write(record)
                        events.write(json.dumps({"label": label, "inicio": start, "fin": end}) + "\n")
                        events.flush()
                        print(result.stdout.strip(), flush=True)
            finally:
                for sampler in samplers:
                    sampler.terminate()
                for sampler in samplers:
                    sampler.wait(timeout=10)

        if name == args.red_config:
            store(directory, "ping.txt", node("master", "ping", "-c", "20", "-i", "0.2",
                                              "worker-1", check=False))
            if args.transport == "proxy":
                store(directory, "iperf-directo.json", node(
                    "master", "iperf3", "-c", "worker-1", "-t", "10", "-J", check=False))
            port = "5202" if args.transport == "proxy" else "5201"
            store(directory, "iperf-escenario.json", node(
                "master", "iperf3", "-c", "worker-1", "-p", port, "-t", "10", "-J", check=False))
    finally:
        for service in nodes:
            store(directory, f"{service}.log",
                  compose("logs", "--tail", "3000", "--no-color", "--timestamps", service, check=False))
            store(directory, f"{service}-tc.txt",
                  node(service, "tc", "-s", "qdisc", "show", "dev", "eth0", check=False))
        ids = compose("ps", "-a", "-q", check=False).stdout.split()
        if ids:
            store(directory, "docker-inspect.json", run(["docker", "inspect", *ids], env, check=False))
        compose("down", "--timeout", "2", check=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--bin", type=Path, required=True)
    parser.add_argument("--logs", type=Path, default=CODE.parent / "logs")
    parser.add_argument("--celdas", nargs="+", default=[f"C{i}-{s}" for i in (2, 1, 3, 4) for s in "AB"])
    parser.add_argument("--transport", choices=("tc", "proxy"), default="proxy")
    parser.add_argument("--master-gib", type=int, choices=(2, 3, 4), default=4)
    parser.add_argument("--tokens", type=int, default=300)
    parser.add_argument("--repeticiones", type=int, default=3)
    parser.add_argument("--red-config", default="C2")
    args = parser.parse_args()
    args.model = args.model.resolve(strict=True)
    args.bin = args.bin.resolve(strict=True)
    args.logs = args.logs.resolve()
    failures = False
    for cell in args.celdas:
        name, scenario = cell.split("-")
        try:
            start_cell(args, name, scenario)
        except (RuntimeError, subprocess.CalledProcessError) as error:
            failures = True
            print(f"{cell}: {error} {getattr(error, 'stderr', '')}", flush=True)
    return int(failures)


if __name__ == "__main__":
    raise SystemExit(main())
