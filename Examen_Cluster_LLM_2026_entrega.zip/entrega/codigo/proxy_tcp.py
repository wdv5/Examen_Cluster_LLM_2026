"""Emulación de flujos TCP en espacio de usuario. Preserva el contenido binario."""
import argparse
import asyncio
import random
from pathlib import Path

MSS = 1460
BLOCK_BYTES = 65536


async def pump(reader, writer, delay, bytes_per_second, loss, rng, enabled):
    while data := await reader.read(BLOCK_BYTES):
        if not enabled.exists():
            writer.write(data)
            await writer.drain()
            continue
        packets = (len(data) + MSS - 1) // MSS
        retry = rng.random() < 1 - (1 - loss) ** packets
        # Aproximación de una retransmisión, sin descartar bytes del flujo TCP.
        await asyncio.sleep(
            delay + len(data) / bytes_per_second + (2 * delay if retry else 0)
        )
        writer.write(data)
        await writer.drain()
    if writer.can_write_eof():
        writer.write_eof()


async def run(args):
    delay = args.delay_ms / 1000
    rate = args.rate_mbps * 1_000_000 / 8
    connection_number = 0
    enabled = Path("/tmp/emular-red")

    async def handle(client_in, client_out):
        nonlocal connection_number
        connection_number += 1
        rng = random.Random(42 + connection_number)
        try:
            upstream_in, upstream_out = await asyncio.open_connection(
                "127.0.0.1", args.target_port
            )
        except OSError as error:
            print(f"No se pudo abrir el destino: {error}", flush=True)
            client_out.close()
            return
        try:
            async with asyncio.TaskGroup() as tasks:
                tasks.create_task(pump(client_in, upstream_out, delay, rate, args.loss, rng, enabled))
                tasks.create_task(pump(upstream_in, client_out, delay, rate, args.loss, rng, enabled))
        except* OSError:
            pass
        finally:
            upstream_out.close()
            client_out.close()

    server = await asyncio.start_server(handle, "0.0.0.0", args.listen_port)
    print(f"Proxy {args.listen_port} → {args.target_port}: {args.delay_ms} ms, "
          f"{args.rate_mbps} Mbps, p={args.loss}", flush=True)
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--listen-port", type=int, required=True)
    parser.add_argument("--target-port", type=int, required=True)
    parser.add_argument("--delay-ms", type=float, required=True)
    parser.add_argument("--rate-mbps", type=float, required=True)
    parser.add_argument("--loss", type=float, required=True)
    asyncio.run(run(parser.parse_args()))
