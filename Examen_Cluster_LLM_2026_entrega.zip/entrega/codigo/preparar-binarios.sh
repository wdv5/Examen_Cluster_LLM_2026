#!/usr/bin/env bash
set -euo pipefail
dest=${1:-"$PWD/dependencias"}
mkdir -p "$dest"
cd "$dest"
commit=2d973636e292ee6f75fadcf08d29cb33511f509f
if [[ ! -d llama.cpp ]]; then
  git clone --depth 1 --branch b9870 https://github.com/ggml-org/llama.cpp.git
fi
test "$(git -C llama.cpp rev-parse HEAD)" = "$commit"
python3 -m venv tools
tools/bin/python -m pip install --only-binary=:all: cmake==3.31.10
tools/bin/cmake -S llama.cpp -B llama.cpp/build -DCMAKE_BUILD_TYPE=Release \
  -DGGML_NATIVE=OFF -DGGML_RPC=ON -DLLAMA_BUILD_TESTS=OFF -DLLAMA_BUILD_EXAMPLES=OFF \
  -DLLAMA_BUILD_TOOLS=ON -DLLAMA_BUILD_SERVER=ON -DLLAMA_BUILD_UI=OFF
tools/bin/cmake --build llama.cpp/build --parallel 4 --target llama-server ggml-rpc-server
