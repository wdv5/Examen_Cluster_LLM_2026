#!/usr/bin/env bash
set -euo pipefail
role=$1 scenario=$2 transport=$3
shift 3
export OMP_WAIT_POLICY=PASSIVE MALLOC_ARENA_MAX=2
case "$scenario" in
  A) delay=0.5; rate=1000; loss=0 ;;
  B) delay=2; rate=100; loss=0.001 ;;
  *) exit 2 ;;
esac

if [[ "$transport" == tc ]]; then
  bash /lab/tc.sh eth0 "$scenario"
fi

if [[ "$role" == worker ]]; then
  iperf3 -s -D -p 5201
  if [[ "$transport" == proxy ]]; then
    python3 -u /lab/proxy_tcp.py --listen-port 50052 --target-port 50053 \
      --delay-ms "$delay" --rate-mbps "$rate" --loss "$loss" &
    python3 -u /lab/proxy_tcp.py --listen-port 5202 --target-port 5201 \
      --delay-ms "$delay" --rate-mbps "$rate" --loss "$loss" &
    ulimit -v 2097152
    exec stdbuf -oL /llama-bin/ggml-rpc-server -H 127.0.0.1 -p 50053 -t 4
  fi
  ulimit -v 2097152
  exec stdbuf -oL /llama-bin/ggml-rpc-server -H 0.0.0.0 -p 50052 -t 4
fi

master_gib=${MASTER_GIB:-4}
case "$master_gib" in
  2|3|4) ulimit -v "$((master_gib * 1024 * 1024))" ;;
  *) exit 2 ;;
esac
exec /llama-bin/llama-server --host 127.0.0.1 --port 8080 --no-ui --parallel 1 \
  --threads 4 --threads-batch 4 --n-gpu-layers all --no-mmap --fit off --flash-attn on \
  --log-verbosity 4 "$@"
