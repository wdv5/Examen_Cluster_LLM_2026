"""Produce las figuras del informe a partir de los datos verificables."""
from datetime import datetime
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import FuncFormatter
import numpy as np

from analizar import ROOT, LOG, MIB, value, lines

FIG = ROOT / "figuras"
A, B, INK, GRAY = "#138277", "#C25537", "#173B50", "#5A7180"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.labelcolor": INK,
    "text.color": INK, "axes.edgecolor": "#9CB1BA", "axes.spines.top": False,
    "axes.spines.right": False, "grid.alpha": .23, "savefig.dpi": 175,
})


def save(fig, name):
    fig.savefig(FIG / f"{name}.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def topology(memory):
    fig, ax = plt.subplots(figsize=(9, 3.3))
    ax.set(xlim=(0, 10), ylim=(0, 4))
    ax.axis("off")

    def box(x, y, width, height, text, color):
        ax.add_patch(FancyBboxPatch((x, y), width, height, boxstyle="round,pad=0.08",
                                   facecolor="#F1F7F8", edgecolor=color, linewidth=1.5))
        ax.text(x + width / 2, y + height / 2, text, ha="center", va="center",
                linespacing=1.32)

    observed = {item["node"]: item["pesos"] for item in memory}
    master = f"{observed['master']:,.0f} MiB de pesos" if "master" in observed else "embeddings locales"
    box(.22, 1.6, 1.74, .9, "Cliente local\nprompt / SSE", INK)
    box(2.78, 1.3, 2.53, 1.48, f"Master · 10.0.50.11\nllama-server · 4 GiB AS\n{master}", INK)
    ax.annotate("", xy=(2.78, 2.05), xytext=(1.96, 2.05), arrowprops={"arrowstyle": "<->", "color": INK})
    for i, y in enumerate((3.02, 1.64, .26), 1):
        name = f"worker-{i}"
        shard = f"{observed[name]:,.0f} MiB de pesos" if name in observed else "shard"
        box(7.17, y, 2.55, .74, f"Worker {i} · 10.0.50.{11+i}\nCPU 2 GiB AS · {shard}", A)
        ax.annotate("", xy=(7.17, y+.37), xytext=(5.31, 2.05),
                    arrowprops={"arrowstyle": "<->", "color": A})
    ax.text(6.34, 3.65, "RPC por proxy", ha="center")
    ax.text(6.2, .17, "Bridge privado 10.0.50.0/24", ha="center", color=GRAY)
    save(fig, "topologia")


def bars(summaries):
    fig, axs = plt.subplots(1, 2, figsize=(9, 3.1), layout="constrained")
    for ax, field, ylabel, threshold, scale in [
        (axs[0], "ttft", "TTFT (s)", 6, .001),
        (axs[1], "tps", "Generación (tok/s)", 1000 / 150, 1),
    ]:
        for side, scenario, color in [(-.185, "A", A), (.185, "B", B)]:
            xs, ys, errors = [], [], []
            for idx in range(4):
                row = summaries.get(f"C{idx+1}-{scenario}")
                if row:
                    xs.append(idx + side)
                    ys.append(value(row, field) * scale)
                    errors.append((row[field]["iqr"] or 0) * scale / 2)
            ax.bar(xs, ys, width=.35, color=color, label=f"Escenario {scenario}",
                   yerr=errors, capsize=2, error_kw={"elinewidth": 1})
        ax.axhline(threshold, ls="--", lw=1, color=GRAY, label="Umbral SLO")
        ax.grid(axis="y")
        ax.set_ylabel(ylabel)
        ax.set_xticks(range(4), ["C1", "C2", "C3", "C4"])
    axs[0].legend(loc="best", fontsize=8)
    save(fig, "metricas-ab")


def trace(raw, config):
    fig, ax = plt.subplots(figsize=(8.8, 2.6), layout="constrained")
    for scenario, color in [("A", A), ("B", B)]:
        rows = raw.get(f"{config}-{scenario}", [])
        if not rows:
            continue
        first = rows[0]
        end = datetime.fromisoformat(first["timestamp"]).timestamp()
        start = end - first["total_ms"] / 1000
        samples = [item for item in lines(LOG / f"{config}-{scenario}/master-telemetria.jsonl")
                   if start <= item["epoch"] <= end]
        if samples:
            base = samples[0]["tx"] + samples[0]["rx"]
            ax.plot([item["epoch"]-start for item in samples],
                    [(item["tx"]+item["rx"]-base)/MIB for item in samples],
                    color=color, label=first["label"])
            ax.axvline(first["ttft_ms"] / 1000, color=color, lw=.85, ls=":")
    ax.set(xlabel="Segundos desde POST", ylabel="Tx + Rx acumulados (MiB)")
    ax.grid()
    if ax.lines:
        ax.legend(fontsize=8)
    save(fig, "traza-red")


def memory_chart(memory):
    fig, ax = plt.subplots(figsize=(8.8, 2.6), layout="constrained")
    if memory:
        baseline = np.zeros(len(memory))
        for field, name, color in [
            ("pesos", "Pesos", INK), ("kv", "KV", A), ("runtime", "Residuo RSS", "#DEA86A"),
            ("libre", "Límite − RSS", "#D8E4E8"),
        ]:
            heights = np.array([row[field] for row in memory])
            ax.bar([row["node"] for row in memory], heights, bottom=baseline,
                   label=name, color=color)
            baseline += heights
        ax.legend(ncol=4, fontsize=8, loc="upper right")
    ax.set(ylabel="MiB por proceso", ylim=(0, 4750))
    ax.grid(axis="y")
    save(fig, "memoria")


def cold(raw, config):
    fig, ax = plt.subplots(figsize=(8.8, 2.2), layout="constrained")
    x = []
    cold_values, warm_values = [], []
    for scenario in ("A", "B"):
        cell = f"{config}-{scenario}"
        rows = raw.get(cell, [])
        warmup = lines(LOG / cell / "warmup.jsonl")
        if rows and warmup:
            x.append(scenario)
            cold_values.append(warmup[0]["ttft_ms"] / 1000)
            warm_values.append(rows[0]["ttft_ms"] / 1000)
    positions = np.arange(len(x))
    ax.bar(positions - .17, cold_values, width=.32, color=INK, label="Primer POST")
    ax.bar(positions + .17, warm_values, width=.32, color=A, label="Segundo POST")
    ax.set(ylabel="TTFT desde /health (s)", xticks=positions, xticklabels=x)
    ax.grid(axis="y")
    if x:
        ax.legend(fontsize=8)
    save(fig, "cold-warm")


def economics(summaries, costs):
    fig, ax = plt.subplots(figsize=(8.8, 3.0), layout="constrained")
    for cell, row in summaries.items():
        r = value(row, "service_tps")
        tokens = r * costs["hours"] * 3600 * 0.5
        unit = costs["cluster"]["tco"] / (costs["op"]["años"] * tokens / 1e6)
        scenario = cell[-1]
        ax.scatter(r, unit, marker="o" if row["slo"] else "x", color=A if scenario == "A" else B)
        peers = sorted(k for k, v in summaries.items() if abs(value(v, "service_tps") - r) < .12)
        offset = peers.index(cell) if cell in peers else 0
        ax.annotate(cell, (r, unit), xytext=(5, 6+11*offset), textcoords="offset points", fontsize=8)
    ax.set(xlabel="Rendimiento efectivo (tokens de salida/s)", ylabel="COP / 1M salida, utilización 50 %")
    ax.grid()
    save(fig, "pareto")

    fig, ax = plt.subplots(figsize=(8.8, 3.2), layout="constrained")
    periods = np.geomspace(1e7, 3e9, 300)
    years = costs["op"]["años"]
    for key, label, color in [("cluster", "Clúster", INK), ("gpu", "RTX 3090 (estimado)", A)]:
        model = costs[key]
        curve = model["tco"] * 1e6 / (years * periods)
        limit = model["tps"] * costs["hours"] * 3600 if model["tps"] else 0
        feasible = periods <= limit
        ax.loglog(periods[feasible]/1e6, curve[feasible], color=color, label=label)
        ax.loglog(periods[~feasible]/1e6, curve[~feasible], color=color, linestyle=":", alpha=.8)
    for api, color in zip(costs["api"], (B, "#856DA6")):
        ax.axhline(api["cop"], color=color, linewidth=1, label=api["name"])
    ax.axvline(costs["demand"] / 1e6, color=GRAY, linestyle="--", label="Demanda")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:,.0f}"))
    ax.set(xlabel="Millones de tokens de salida por año", ylabel="COP / 1M de salida")
    ax.grid(which="major")
    ax.legend(ncol=2, fontsize=8)
    save(fig, "break-even")
