#!/usr/bin/env bash
set -euo pipefail
model=$(realpath "$1")
model_bytes=$(stat -c '%s' "$model")
blocks=$((model_bytes / 4194304))
date -u +%FT%TZ
printf 'bytes_archivo=%s bloques_completos_4194304=%s\n' "$model_bytes" "$blocks"
LC_ALL=C dd if="$model" of=/dev/null bs=4M iflag=direct count="$blocks" status=progress
