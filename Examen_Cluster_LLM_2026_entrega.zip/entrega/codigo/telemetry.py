import json
import time
from pathlib import Path

cgroup = Path("/sys/fs/cgroup")
net = Path("/sys/class/net/eth0/statistics")
fields = {
    "tx": net / "tx_bytes",
    "rx": net / "rx_bytes",
    "tx_dropped": net / "tx_dropped",
    "rx_dropped": net / "rx_dropped",
}

pid_status = Path("/proc/1/status")
limits = cgroup / "memory.max"
def memory():
    fields = {}
    for line in pid_status.read_text().splitlines():
        key, _, value = line.partition(":")
        if key in {"VmRSS", "VmHWM", "VmSize"}:
            fields[key] = 1024 * int(value.split()[0])
    return fields

while True:
    sample = {key: int(path.read_text()) for key, path in fields.items()}
    print(json.dumps({"epoch": time.time(), **sample, **memory(), "cgroup_memory_max": limits.read_text().strip()}), flush=True)
    time.sleep(0.5)
