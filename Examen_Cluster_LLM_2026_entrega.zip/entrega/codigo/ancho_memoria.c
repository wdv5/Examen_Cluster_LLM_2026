// Cota de lectura secuencial sobre un arreglo mayor que la caché por CCD.
#include <omp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    const size_t bytes = 768UL * 1024 * 1024;
    const size_t elements = bytes / sizeof(uint64_t);
    uint64_t *data = aligned_alloc(64, bytes);
    if (data == NULL) {
        return 1;
    }
    #pragma omp parallel for schedule(static)
    for (size_t i = 0; i < elements; ++i) {
        data[i] = i & 255;
    }

    printf("{\"bytes\":%zu,\"hilos\":%d,\"muestras_gb_s\":[",
           bytes, omp_get_max_threads());
    uint64_t checksum = 0;
    for (int repetition = 0; repetition < 5; ++repetition) {
        uint64_t subtotal = 0;
        const double start = omp_get_wtime();
        #pragma omp parallel for reduction(+:subtotal) schedule(static)
        for (size_t i = 0; i < elements; ++i) {
            subtotal += data[i];
        }
        const double duration = omp_get_wtime() - start;
        checksum += subtotal;
        printf("%s%.6f", repetition ? "," : "", bytes / duration / 1e9);
    }
    printf("],\"suma_control\":%llu}\n", (unsigned long long)checksum);
    free(data);
    return checksum != 5 * elements * 255 / 2;
}
