"""RTT de aplicación con mensajes eco de 64 B y una conexión persistente."""
import argparse
import json
import socket
import socketserver
from statistics import mean, pstdev
from time import perf_counter, sleep

SIZE = 64


def recv_exact(sock):
    buffer = bytearray()
    while len(buffer) < SIZE:
        data = sock.recv(SIZE - len(buffer))
        if not data:
            return None
        buffer.extend(data)
    return bytes(buffer)


class Echo(socketserver.BaseRequestHandler):
    def handle(self):
        while (message := recv_exact(self.request)) is not None:
            self.request.sendall(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--server", action="store_true")
    args = parser.parse_args()
    if args.server:
        with socketserver.TCPServer((args.host, args.port), Echo) as server:
            server.serve_forever()
        return

    samples = []
    with socket.create_connection((args.host, args.port), timeout=3) as sock:
        for i in range(100):
            payload = i.to_bytes(SIZE, "big")
            start = perf_counter()
            sock.sendall(payload)
            response = recv_exact(sock)
            samples.append(1000 * (perf_counter() - start))
            assert response == payload, "El eco TCP se alteró"
            sleep(.025)
    print(json.dumps({"bytes": SIZE, "n": len(samples), "mean_ms": mean(samples),
                      "stdev_ms": pstdev(samples), "samples_ms": samples}))


if __name__ == "__main__":
    main()
