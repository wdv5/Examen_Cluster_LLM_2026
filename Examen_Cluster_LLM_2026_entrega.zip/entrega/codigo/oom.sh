#!/usr/bin/env bash
set -euo pipefail
bin=$(realpath "$1")
model=$(realpath "$2")
logs=$(realpath -m "$3")
mkdir -p "$logs"
container=$(docker create --memory 2g --memory-swap 2g --network none \
  -v "$bin:/llama-bin:ro" -v "$model:/model.gguf:ro" \
  examen-cluster-cpu:trixie prlimit --as=2147483648:2147483648 /llama-bin/llama-server --model /model.gguf \
  --no-mmap --fit off --n-gpu-layers all --ctx-size 2048 --parallel 1 \
  --threads 2 --host 127.0.0.1 --port 8080 --no-ui --log-verbosity 4)
trap 'docker rm -f "$container" >/dev/null' EXIT
printf 'UTC %s\n' "$(date -u +%FT%TZ)" > "$logs/oom-estado.txt"
docker start "$container" >/dev/null
timeout 120 docker wait "$container" | tee "$logs/oom-exit.txt"
docker logs --timestamps "$container" > "$logs/oom.log" 2>&1
docker inspect -f '{{json .State}}' "$container" >> "$logs/oom-estado.txt"
cat "$logs/oom-estado.txt"
python3 - "$logs/oom-estado.txt" <<'PY'
import json
from pathlib import Path
import sys
s = json.loads(Path(sys.argv[1]).read_text().splitlines()[-1])
log = Path(sys.argv[1]).with_name("oom.log").read_text().lower()
allocation_failed = any(text in log for text in ("failed to allocate", "out of memory", "bad_alloc", "cannot allocate memory"))
assert s["OOMKilled"] or (s["ExitCode"] != 0 and allocation_failed), s
PY
