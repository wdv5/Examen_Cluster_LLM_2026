"""Genera el libro editable con entradas, fórmulas y resultados en caché."""
from pathlib import Path
import xlsxwriter

from analizar import FUENTES, KV_BYTES, MODEL_BYTES, PARAMS


def workbook(path: Path, cost, basis):
    op, cluster, gpu = (cost[k] for k in ("op", "cluster", "gpu"))
    rate = cluster["tps"]
    annual = cost["annual_capacity"]
    years = op["años"]
    demand = cost["demand"]
    out = xlsxwriter.Workbook(path)
    banner = out.add_format({"bold": True, "font_size": 15, "font_color": "#173B50"})
    head = out.add_format({"bold": True, "bg_color": "#173B50", "font_color": "white",
                           "text_wrap": True, "valign": "vcenter"})
    note = out.add_format({"font_color": "#445766", "text_wrap": True, "valign": "vcenter"})
    cash_in = out.add_format({"bg_color": "#FFF2CC", "num_format": "#,##0.00"})
    cash = out.add_format({"bg_color": "#F2F5F7", "num_format": "#,##0.00"})
    percent = out.add_format({"bg_color": "#FFF2CC", "num_format": "0%"})
    text_in = out.add_format({"bg_color": "#FFF2CC"})

    def sheet(name, title, headers, widths):
        page = out.add_worksheet(name)
        page.hide_gridlines(2)
        page.freeze_panes(3, 0)
        for i, width in enumerate(widths):
            page.set_column(i, i, width)
        page.merge_range(0, 0, 0, len(headers) - 1, title, banner)
        page.set_row(2, 29)
        page.write_row(2, 0, headers, head)
        return page

    def formula(page, cell, equation, result):
        page.write_formula(cell, equation, cash, result if result is not None else "")

    def divide(numerator, denominator):
        return numerator / denominator if denominator else None

    info = sheet("Instrucciones", "Costos del piloto y del escenario Andina AI",
                 ["Tema", "Criterio de cálculo"], [32, 110])
    for i, row in enumerate([
        ("Base", "COP nominales, 3 años, residual cero. Complete precios antes de comprar."),
        ("Activos existentes", "CAPEX de reposición en la hoja principal. UPS e instalación son el desembolso incremental del clúster."),
        ("Depreciación", "Informativa. El flujo de caja ya incluye CAPEX."),
        ("Métrica de capacidad", f"{basis} · tokens de salida / segundo de servicio completo; una solicitud activa."),
        ("Potencia", "750 W clúster y 450 W GPU son hipótesis económicas. El host cloud carece de medición de energía."),
        ("API", "Tarifa de entrada sin caché más salida para una razón entrada/salida de 1. Se excluyen impuestos y créditos."),
        ("Precios locales", "UPS, NVMe, HDD y NIC según Tauret. El resto usa referencias del enunciado o la plantilla."),
        ("Lectura", "Amarillo indica una entrada. Gris indica una fórmula. Las hojas usan unidades de salida en el denominador."),
    ], 3):
        info.set_row(i, 27)
        info.write(i, 0, row[0])
        info.write(i, 1, row[1], note)

    cap = sheet("CAPEX", "CAPEX de reposición e inversión nueva",
                ["Ítem", "Cantidad", "COP unitario", "COP total", "Fuente", "Consulta"], [39, 12, 18, 18, 29, 17])
    for i, (label, quantity, unit, source) in enumerate(FUENTES["capex"], 4):
        cap.write(i - 1, 0, label)
        cap.write_number(f"B{i}", quantity, cash_in)
        cap.write_number(f"C{i}", unit, cash_in)
        formula(cap, f"D{i}", f"=B{i}*C{i}", quantity * unit)
        if source.startswith("https:"):
            cap.write_url(f"E{i}", source, string="Tauret Computadores")
        else:
            cap.write(f"E{i}", source)
        cap.write(f"F{i}", FUENTES["consulta"])
    cap.write("A10", "Clúster, reposición")
    formula(cap, "D10", "=SUM(D4:D9)", cluster["capex"])
    cap.write("A11", "Clúster, desembolso incremental")
    incremental = sum(row[1] * row[2] for row in FUENTES["capex"][-2:])
    formula(cap, "D11", "=SUM(D8:D9)", incremental)
    cap.write("A12", "Servidor RTX 3090, presupuesto")
    cap.write_number("D12", gpu["capex"], cash_in)
    cap.write("E12", "Plantilla, comparativo B")
    cap.write("A13", "NIC 10 GbE (x4) y switch estimado")
    cap.write_number("B13", FUENTES["nic_10gbe_cop"], cash_in)
    cap.write_number("C13", FUENTES["switch_10gbe_cop_supuesto"], cash_in)
    formula(cap, "D13", "=4*B13+C13", 4 * FUENTES["nic_10gbe_cop"] + FUENTES["switch_10gbe_cop_supuesto"])
    cap.write_url("E13", FUENTES["fuentes_locales"]["NIC 10 GbE"], string="Tauret · NIC")

    opex = sheet("OPEX", "OPEX anual por escenario local",
                 ["Parámetro", "Clúster", "GPU única", "Base"], [30, 18, 18, 57])
    input_rows = [
        ("Potencia (W)", cluster["watts"], gpu["watts"], "Supuesto de potencia de pared."),
        ("Horas/día", op["horas_dia"], op["horas_dia"], "Enunciado."),
        ("Días/año", op["dias_año"], op["dias_año"], "Enunciado."),
        ("Tarifa (COP/kWh)", op["tarifa_kwh"], op["tarifa_kwh"], "Enunciado."),
        ("Internet (COP/mes)", op["internet_mes"], op["internet_mes"], "Se asigna completo a cada alternativa."),
        ("Mantenimiento (%)", op["mantenimiento"], op["mantenimiento"], "Sobre CAPEX de reposición."),
        ("Vida útil (años)", years, years, "Horizonte de análisis."),
    ]
    for i, (label, a, b, memo) in enumerate(input_rows, 4):
        opex.write(f"A{i}", label)
        opex.write_number(f"B{i}", a, percent if i == 9 else cash_in)
        opex.write_number(f"C{i}", b, percent if i == 9 else cash_in)
        opex.write(f"D{i}", memo)
    for col, model, capex_ref in [("B", cluster, "D10"), ("C", gpu, "D12")]:
        for i, label in enumerate(["Energía", "Internet", "Mantenimiento", "Depreciación informativa", "OPEX de caja"], 11):
            opex.write(f"A{i}", label)
        formula(opex, f"{col}11", f"={col}4*{col}5*{col}6*{col}7/1000", model["energy"])
        formula(opex, f"{col}12", f"={col}8*12", 12 * op["internet_mes"])
        formula(opex, f"{col}13", f"={col}9*CAPEX!{capex_ref}", model["capex"] * op["mantenimiento"])
        formula(opex, f"{col}14", f"=CAPEX!{capex_ref}/{col}10", model["capex"] / years)
        formula(opex, f"{col}15", f"=SUM({col}11:{col}13)", model["opex"])

    tco = sheet("TCO", "TCO por volumen (COP y tokens de salida)",
                ["Criterio", "Clúster", "GPU única", "Detalle"], [37, 22, 22, 68])
    for row, label in enumerate(["TCO de reposición a 3 años", "Tok/s de servicio / estimación",
                                 "Capacidad anual al 100 %", "Demanda anual", "COP/1M según demanda",
                                 "Utilización 25 %", "Utilización 50 %", "Utilización 100 %",
                                 "TCO incremental clúster", "Solicitudes/día", "Salida por solicitud",
                                 "Entrada por solicitud"], 4):
        tco.write(f"A{row}", label)
    tco.write_number("B5", rate or 0, cash_in)
    tco.write("D5", basis)
    tco.write_number("B13", op["solicitudes_dia"], cash_in)
    tco.write_number("B14", op["tokens_salida"], cash_in)
    tco.write_number("B15", op["tokens_entrada"], cash_in)
    tco.write_number("C16", FUENTES["gpu_bandwidth_gb_s"], cash_in)
    tco.write_number("C17", FUENTES["gpu_tflops_fp32"], cash_in)
    tco.write_number("C18", FUENTES["gpu_fraction_bw"], percent)
    tco.write_number("C19", MODEL_BYTES, cash_in)
    tco.write_number("C20", KV_BYTES * 4096, cash_in)
    tco.write_number("C21", PARAMS, cash_in)
    for i, label in enumerate(["GB/s VRAM", "TFLOP/s FP32", "Factor efectivo supuesto",
                                "Bytes GGUF", "Bytes KV 4K", "Parámetros"], 16):
        tco.write(f"A{i}", label)
    formula(tco, "C5", "=MIN(C16*1E9/(C19+C20),C17*1E12/(2*C21))*C18", gpu["tps"])
    for col, model, capex_ref in [("B", cluster, "D10"), ("C", gpu, "D12")]:
        capacity = model["tps"] * cost["hours"] * 3600 if model["tps"] else None
        formula(tco, f"{col}4", f"=CAPEX!{capex_ref}+OPEX!{col}15*OPEX!{col}10", model["tco"])
        formula(tco, f"{col}6", f"={col}5*OPEX!{col}5*OPEX!{col}6*3600", capacity or 0)
        formula(tco, f"{col}7", f"=$B$13*$B$14*OPEX!{col}6", demand)
        formula(tco, f"{col}8", f"={col}4*1E6/({col}7*OPEX!{col}10)", model["tco"]*1e6/(years*demand))
        for i, utilization in enumerate((0.25, 0.5, 1), 9):
            total = divide(model["tco"]*1e6, years*capacity*utilization if capacity else None)
            formula(tco, f"{col}{i}", f'=IF({col}6>0,{col}4*1E6/({col}6*OPEX!{col}10*{utilization}),"")', total)
    formula(tco, "B12", "=CAPEX!D11+OPEX!B15*OPEX!B10", incremental+years*cluster["opex"])

    compare = sheet("Comparacion", "Opciones en pesos a demanda de diseño",
                    ["Opción", "CAPEX", "OPEX/año", "TCO 3 años", "Tok/s", "COP/1M", "Latencia", "Privacidad", "Riesgo / método"],
                    [33, 16, 16, 17, 13, 16, 27, 13, 44])
    for row, col, model, cap_ref, name, risk in [
        (4, "B", cluster, "D10", "Clúster", "Perfil B CPU medido; costo de escenario físico."),
        (5, "C", gpu, "D12", "Servidor RTX 3090", "Roofline con factor supuesto. Punto único de falla."),
    ]:
        compare.write(f"A{row}", name)
        formula(compare, f"B{row}", f"=CAPEX!{cap_ref}", model["capex"])
        formula(compare, f"C{row}", f"=OPEX!{col}15", model["opex"])
        formula(compare, f"D{row}", f"=TCO!{col}4", model["tco"])
        formula(compare, f"E{row}", f"=TCO!{col}5", model["tps"] or 0)
        formula(compare, f"F{row}", f"=TCO!{col}8", model["tco"]*1e6/(years*demand))
        compare.write(f"G{row}", "Medida en logs" if col == "B" else "Requiere validación")
        compare.write(f"H{row}", "Sí, local")
        compare.write(f"I{row}", risk)
    for i, api in enumerate(cost["api"], 6):
        api_row = i - 2
        compare.write(f"A{i}", api["name"])
        compare.write_number(f"B{i}", 0, cash)
        formula(compare, f"C{i}", f"=BreakEven!E{api_row}*TCO!B7/1E6", api["cop"]*demand/1e6)
        formula(compare, f"D{i}", f"=C{i}*OPEX!B10", api["cop"]*demand*years/1e6)
        formula(compare, f"F{i}", f"=BreakEven!E{api_row}", api["cop"])
        compare.write(f"G{i}", "Remota, sin medir")
        compare.write(f"H{i}", "No")
        compare.write_url(f"I{i}", api["url"], string="Tarifa oficial")

    be = sheet("BreakEven", "Punto de equilibrio contra tarifas API",
               ["Modelo", "USD/1M entrada", "USD/1M salida", "TRM COP/USD", "COP/1M salida equivalente",
                "Salida/año equilibrio", "Tok/s necesarios", "Capacidad suficiente", "Fuente"],
               [33, 17, 17, 17, 23, 22, 19, 20, 23])
    for i, api in enumerate(cost["api"], 4):
        threshold = cluster["tco"] / years / api["cop"] * 1e6
        be.write(f"A{i}", api["name"])
        be.write_number(f"B{i}", api["in"], cash_in)
        be.write_number(f"C{i}", api["out"], cash_in)
        be.write_number(f"D{i}", FUENTES["trm_cop_usd"], cash_in)
        formula(be, f"E{i}", f"=(B{i}*TCO!B15/TCO!B14+C{i})*D{i}", api["cop"])
        formula(be, f"F{i}", f"=TCO!B4/OPEX!B10/E{i}*1E6", threshold)
        formula(be, f"G{i}", f"=F{i}/(3600*OPEX!B5*OPEX!B6)", threshold / (3600*cost["hours"]))
        be.write_formula(f"H{i}", f'=IF(TCO!B6>=F{i},"Sí","No")', None, "Sí" if annual and annual >= threshold else "No")
        be.write_url(f"I{i}", api["url"], string="Proveedor")
    be.write_url("I7", FUENTES["fuentes_locales"]["TRM"], string="Datos Abiertos · TRM")

    sens = sheet("Sensibilidad", "Variaciones a un factor",
                 ["Caso", "Valor", "TCO clúster", "COP/1M clúster", "Equilibrio salida/año", "Base"], [25, 18, 19, 20, 24, 38])
    index = 4
    for power_price in (600, 800, 1000):
        tco_adjusted = cluster["tco"] + years*cluster["energy"]*(power_price/op["tarifa_kwh"]-1)
        sens.write(f"A{index}", "Energía (COP/kWh)")
        sens.write_number(f"B{index}", power_price, cash_in)
        formula(sens, f"C{index}", f"=TCO!B4+OPEX!B10*OPEX!B11*(B{index}/OPEX!B7-1)", tco_adjusted)
        formula(sens, f"D{index}", f"=C{index}*1E6/(TCO!B7*OPEX!B10)", tco_adjusted*1e6/demand/years)
        sens.write(f"F{index}", "Demanda fija")
        index += 1
    for utilization in (0.25, 0.5, 1):
        for relative_rate in (0.7, 1, 1.3):
            sens.write(f"A{index}", f"Utilización {utilization:.0%}")
            sens.write_number(f"B{index}", relative_rate, percent)
            formula(sens, f"C{index}", "=TCO!B4", cluster["tco"])
            denominator = annual*utilization*relative_rate*years if annual else None
            formula(sens, f"D{index}", f'=IF(TCO!B6>0,C{index}*1E6/(TCO!B6*{utilization}*B{index}*OPEX!B10),"")',
                    divide(cluster["tco"]*1e6, denominator))
            sens.write(f"F{index}", "Factor de throughput")
            index += 1
    for api_row, api in enumerate(cost["api"], 4):
        for scale in (.5, 1, 1.5):
            sens.write(f"A{index}", f"API {api_row-3}, tarifa")
            sens.write_number(f"B{index}", scale, percent)
            formula(sens, f"E{index}", f"=TCO!B4*1E6/(OPEX!B10*BreakEven!E{api_row}*B{index})",
                    cluster["tco"]*1e6/(years*api["cop"]*scale))
            sens.write(f"F{index}", api["name"])
            index += 1

    storage = sheet("Almacenamiento", "Comparación de almacenamiento",
                    ["Medio", "Capacidad GB", "COP", "MB/s supuesto", "COP/GB", "Lectura archivo (s)", "Fuente"],
                    [19, 17, 17, 21, 17, 21, 26])
    for i, (label, tb, price, bw) in enumerate(FUENTES["almacenamiento"], 4):
        storage.write(f"A{i}", label)
        storage.write_number(f"B{i}", tb*1000, cash_in)
        storage.write_number(f"C{i}", price, cash_in)
        storage.write_number(f"D{i}", bw, cash_in)
        formula(storage, f"E{i}", f"=C{i}/B{i}", price/(tb*1000))
        formula(storage, f"F{i}", f"=TCO!C19/1E6/D{i}", MODEL_BYTES/1e6/bw)
        if label in FUENTES["fuentes_locales"]:
            storage.write_url(f"G{i}", FUENTES["fuentes_locales"][label], string="Tauret")
        else:
            storage.write(f"G{i}", "Plantilla UTB")
    out.close()
