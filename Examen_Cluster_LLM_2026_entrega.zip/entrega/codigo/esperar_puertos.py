import socket
import sys
import time

for port in map(int, sys.argv[1:]):
    for attempt in range(30):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                break
        except OSError:
            if attempt == 29:
                raise
            time.sleep(0.2)
