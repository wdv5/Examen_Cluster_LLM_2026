"""Regenera informe, hoja de costos y figuras desde el experimento."""
import csv
from datetime import datetime
import html
import json
import math
import re

from statistics import median

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from analizar import (ROOT, LOG, MIB, MODEL_BYTES, FUENTES, metrics, summarize, prices,
                      node_memory, value, lines)
from costos import workbook
import graficos as charts

FIG = ROOT / "figuras"
INK = colors.HexColor("#173B50")
TEAL = colors.HexColor("#136D65")
MUTED = colors.HexColor("#526774")
WHITE = colors.white
PALE = colors.HexColor("#EDF4F5")

for style, filename in [("Regular", "DejaVuSans.ttf"), ("Bold", "DejaVuSans-Bold.ttf")]:
    pdfmetrics.registerFont(TTFont(style, f"/usr/share/fonts/truetype/dejavu/{filename}"))
pdfmetrics.registerFontFamily("Regular", normal="Regular", bold="Bold", italic="Regular", boldItalic="Bold")

BODY = ParagraphStyle("body", fontName="Regular", fontSize=10, leading=14, textColor=INK, spaceAfter=8)
TITLE = ParagraphStyle("title", fontName="Bold", fontSize=26, leading=31, textColor=INK, spaceAfter=14)
SUB = ParagraphStyle("sub", fontName="Bold", fontSize=13, leading=18, textColor=TEAL, spaceBefore=8, spaceAfter=6)
SMALL = ParagraphStyle("small", parent=BODY, fontSize=8, leading=12, textColor=MUTED, spaceAfter=8)
TABLE = ParagraphStyle("table", parent=SMALL, fontSize=8, leading=11, textColor=INK, spaceAfter=0)
HEADER = ParagraphStyle("head", parent=TABLE, fontName="Bold", textColor=WHITE)
CHIP = ParagraphStyle("chip", parent=SMALL, fontName="Bold", textColor=TEAL, spaceAfter=7)


def qty(number, digits=0):
    if number is None:
        return "—"
    return f"{number:,.{digits}f}".replace(",", "\u202f").replace(".", ",")


def esc(text):
    return html.escape(str(text))


def info_for(raw, cell):
    p = LOG / cell / "inicio.json"
    cold = lines(LOG / cell / "warmup.jsonl")
    rows = raw.get(cell, [])
    if not p.exists():
        return [None] * 3
    return [json.loads(p.read_text())["segundos_hasta_health"],
            cold[0]["ttft_ms"] / 1000 if cold else None,
            rows[0]["ttft_ms"] / 1000 if rows else None]


def network(scenario):
    p = LOG / f"C2-{scenario}"
    ping = (p / "ping.txt").read_text() if (p / "ping.txt").exists() else ""
    m = re.search(r"rtt .*?= ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)", ping)
    loss = re.search(r"([\d.]+)% packet loss", ping)
    result = {"rtt": float(m[2]) if m else None, "mdev": float(m[4]) if m else None,
              "loss": float(loss[1]) if loss else None}
    probe = LOG / "red" / f"rtt-{scenario}.json"
    shaped = json.loads(probe.read_text()) if probe.exists() and probe.stat().st_size else {}
    result["rtt_aplicacion"] = median(shaped["samples_ms"]) if shaped.get("samples_ms") else None
    result["rtt_aplicacion_sd"] = shaped.get("stdev_ms")
    for key in ("directo", "escenario"):
        filename = p / f"iperf-{key}.json"
        doc = json.loads(filename.read_text()) if filename.exists() and filename.stat().st_size else {}
        result[key] = doc.get("end", {}).get("sum_received", {}).get("bits_per_second")
        if result[key] is not None:
            result[key] /= 1e6
        result[f"{key}_retrans"] = doc.get("end", {}).get("sum_sent", {}).get("retransmits")
    return result


def mark(row):
    if row is None or row["n"] < 3:
        return "Pendiente"
    return "Sí" if row["slo"] else "No"


def elapsed_download():
    p = LOG / "modelo.txt"
    if not p.exists():
        return None
    m = re.search(r"inicio_descarga=(.*?) ultimo_byte=(.*)", p.read_text())
    if not m:
        return None
    return (datetime.fromisoformat(m[2]) - datetime.fromisoformat(m[1])).total_seconds()


def measurements_csv(data):
    columns = ["celda", "n", "slo"] + [
        f"{name}_{item}" for name in ("ttft", "prefill", "tps", "tpot", "total_ms", "service_tps", "tokens", "rss", "tx", "rx")
        for item in ("median", "iqr")
    ]
    with (ROOT / "resultados.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for cell, row in data.items():
            r = {"celda": cell, "n": row["n"], "slo": mark(row)}
            for field in columns[3:]:
                name, stat = field.rsplit("_", 1)
                r[field] = row[name][stat]
            writer.writerow(r)


def produce():
    raw = metrics()
    data = summarize()
    candidates = {k: v for k, v in data.items() if k.endswith("-A") and v["n"] == 3
                  and k.startswith(("C2", "C4"))}
    paired = {key: row for key, row in candidates.items()
              if row["slo"] and data.get(key[:2]+"-B", {}).get("n") == 3
              and data[key[:2]+"-B"]["slo"]}
    selection_pool = paired or candidates
    baseline = max(selection_pool, key=lambda c: value(selection_pool[c], "service_tps")) if selection_pool else None
    comparison_basis = f"{baseline}, piloto CPU con contexto 4K" if baseline else "Sin celda 4K finalizada"
    cost = prices(value(data[baseline], "service_tps") if baseline else None)
    model = cost["cluster"]
    gpu = cost["gpu"]
    years = cost["op"]["años"]
    demand = cost["demand"]
    base_config = baseline[:2] if baseline else "C2"
    bases = [k for k in ("C2-A", "C4-A") if node_memory(k)]
    memory_cell = baseline if baseline and node_memory(baseline) else (bases[0] if bases else "C2-A")
    memory = node_memory(memory_cell)
    nets = {scenario: network(scenario) for scenario in "AB"}
    complete = sum(row["n"] == 3 for row in data.values())
    fig_args = [
        (charts.topology, (memory,)), (charts.bars, (data,)),
        (charts.trace, (raw, base_config)), (charts.memory_chart, (memory,)),
        (charts.cold, (raw, base_config)), (charts.economics, (data, cost)),
    ]
    for chart, args in fig_args:
        chart(*args)
    workbook(ROOT / "costos.xlsx", cost, comparison_basis)
    measurements_csv(data)
    (ROOT / "resumen.json").write_text(json.dumps({
        "celdas": data, "base_economica": baseline, "ganadora_slo_4k": baseline if paired else None,
        "costos": cost, "memoria": memory, "red": nets,
    }, ensure_ascii=False, indent=2) + "\n")

    story = []
    page = 0
    def p(text, style=BODY):
        story.append(Paragraph(text, style))

    def title(name, category):
        nonlocal page
        if page:
            story.append(PageBreak())
        page += 1
        p(category, CHIP)
        p(name, TITLE)

    def sub(text):
        p(text, SUB)

    def small(text):
        p(text, SMALL)

    def table(headings, rows, widths):
        data = [[Paragraph(esc(x), HEADER) for x in headings]] + [
            [Paragraph(esc(x), TABLE) for x in row] for row in rows
        ]
        element = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
        element.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), INK),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [PALE, WHITE]),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 7),
            ("RIGHTPADDING", (0, 0), (-1, -1), 7),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(element)
        story.append(Spacer(1, 9))

    def chart(name, caption, height):
        path = FIG / f"{name}.png"
        width0, height0 = ImageReader(str(path)).getSize()
        multiplier = min(504 / width0, height / height0)
        story.append(Image(str(path), width=width0*multiplier, height=height0*multiplier))
        small(caption)

    def source(url, label):
        return f'<link href="{esc(url)}" color="#136D65">{esc(label)}</link>'

    title("Clúster distribuido de inferencia LLM", "Examen integrador · Arquitectura de computadores · UTB")
    p("Evaluación experimental y económica para Andina AI", SUB)
    p("Perfil B · Qwen2.5-3B-Instruct Q8_0 · 27 de noviembre de 2026")
    sub("Resumen ejecutivo")
    if paired:
        p(f"<b>{baseline[:2]}</b> fue la configuración 4K de menor costo por millón entre las que cumplieron ambas redes en cada repetición. La prueba cubre una solicitud activa; la capacidad para picos y la disponibilidad siguen pendientes.")
    elif complete == 8:
        if all(not row["slo"] for row in data.values()):
            p("<b>Ninguna de las ocho celdas cumplió el SLO completo.</b> El montaje distribuyó el Qwen real, y la carga completa bajo 2 GiB falló por falta de memoria. La prueba de una sola sesión mide una condición más favorable que el pico de producción.")
        else:
            p("<b>Ninguna configuración 4K cumplió el SLO completo en ambas redes.</b> El modelo requirió varios procesos bajo el límite de 2 GiB.")

    else:
        p(f"<b>Resultado provisional.</b> Se completaron {complete} de 8 celdas experimentales. Las celdas sin las tres repeticiones se identifican en la tabla de resultados.")
    if baseline:
        b = data[baseline]
        p(f"La referencia económica usa <b>{baseline}</b>, con {qty(value(b, 'ttft')/1000, 2)} s de TTFT, "
          f"{qty(value(b,'tps'),2)} tok/s de generación y {qty(value(b,'service_tps'),2)} tok/s tras incluir prefill. "
          f"En esa referencia, el clúster cuesta COP {qty(model['tco']/(years*demand/1e6))} por millón de salida a la demanda teórica. "
          "La capacidad y el SLO condicionan que ese denominador sea realizable.")
    p("El objetivo de 500 solicitudes diarias requiere 37,5 millones de tokens de salida al año. El pico de 3 req/s requiere entregar 900 tokens/s sostenidos si se mantiene durante el tiempo de respuesta. La privacidad exige ejecución local.")
    sub("Decisión")
    p("Probar primero un modelo de licencia comercial en la RTX 3060 que Andina AI ya tiene. Evaluar una GPU local de 24 GB si la prueba de calidad, latencia o concurrencia lo exige. Mantener el clúster para investigación y trabajos tolerantes a la latencia.")
    table(["Concepto", "Resultado"], [
        ("Clúster, CAPEX de reposición", f"COP {qty(model['capex'])}"),
        ("Clúster, TCO nominal a 3 años", f"COP {qty(model['tco'])}"),
        ("RTX 3090, TCO nominal a 3 años", f"COP {qty(gpu['tco'])}"),
        ("Restricción de licencia", "Qwen Research License. El uso comercial exige licencia del proveedor."),
    ], [225, 279])

    title("Modelo y topología", "Arquitectura")
    p("El host expone una CPU AMD EPYC 9V74, cuota de 4 vCPU y 32 GiB globales. El laboratorio separa los procesos en una red Docker interna. Master y workers comparten CPU, memoria y almacenamiento físicos.")
    chart("topologia", f"Figura 1. IP, rol y buffers de pesos. Referencia {memory_cell}. AS indica el espacio de direcciones limitado por proceso.", 228)
    table(["Modelo y pesos", "Valor"], [
        ("Qwen2.5-3B-Instruct Q8_0", "3,09 mil millones de parámetros · 36 capas · hidden 2 048 · 16 cabezas Q · 2 cabezas KV"),
        ("Dimensión de cada cabeza", "128"),
        ("Peso homogéneo teórico", "3,09 × 10⁹ × 34/32 B = 3,283 GB"),
        ("GGUF exacto", "3 616 088 480 B · 3,616 GB · 3,368 GiB"),
    ], [177, 327])
    p("El master mantiene embeddings y coordina la evaluación. Los workers alojan grupos de capas y sus cachés; el último también recibe la salida. Cada flecha RPC incluye transferencia de pesos al arrancar y comandos, tensores y sincronizaciones durante inferencia.")
    small("El SHA-256 completo aparece en prelab.md y logs/modelo.txt. " + source(
        "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/tree/7dabda4d13d513e3e842b20f0d435c732f172cbe", "Modelo oficial"))

    title("Protocolo y evidencia de partición", "Metodología")
    p("Se limitó el espacio de direcciones del master a 4 GiB y cada worker a 2 GiB. El kernel de la sesión expone 32 GiB de memory.max aunque Compose declara límites menores; se verificaron los límites efectivos en /proc/1/limits. El master abrió el modelo con --no-mmap y asignación automática desactivada.")
    p("La carga local sin RPC con 2 GiB solicitó un buffer de 3 610 132 480 B. El asignador rechazó la reserva y el servidor salió con código 1; Docker indicó OOMKilled=false. Los buffers RPC positivos del ensayo distribuido confirman que la ruta de inferencia es distinta. El master de 4 GiB puede contener los pesos en teoría, con margen condicionado por KV, buffers y espacio virtual.")
    strict = LOG / "estricto/C2-A/inicio.json"
    strict_result = LOG / "estricto/metricas.jsonl"
    if strict.exists() and strict_result.exists():
        strict_limit = json.loads(strict.read_text())["master_gib"]
        p(f"Se comprobó además el montaje C2 en modo estricto, con el master limitado a {strict_limit} GiB "
          "y cada worker a 2 GiB. Esa prueba corta cargó el mismo Qwen y generó texto. "
          "Todos los límites de proceso quedaron por debajo del tamaño de los pesos.")
    table(["Celda", "Workers", "Contexto", "Split", "KV", "Intención"], [
        ("C1", "3", "2 048", "1,1,1", "FP16", "Base 2K"),
        ("C2", "3", "4 096", "1,1,1", "FP16", "Base para SLO 4K"),
        ("C3", "2", "2 048", "1,1", "FP16", "Menos etapas remotas"),
        ("C4", "3", "4 096", "1.15,1.15,0.70", "FP16", "Reduce el peso del último worker"),
    ], [52, 64, 67, 99, 54, 168])
    p("Cada celda inicia procesos nuevos y usa POSIX_FADV_DONTNEED sobre el GGUF como solicitud consultiva al SO. El proxy aplica A o B una vez disponible /health. El cliente desactiva cache_prompt y usa el prompt intacto, temperatura 0, semilla 42 y máximo 300 tokens. Se descarta el calentamiento de las medianas. La red se mide después de las repeticiones.")
    first_record = next((rows[0] for rows in raw.values() if rows), None)
    if first_record:
        p(f"El Qwen tokenizó el prompt del examen en {first_record['timings']['prompt_n']} tokens. "
          "El modelo de demanda conserva los 300 tokens de entrada y salida definidos por Andina AI.")
    p("Cuatro hilos por worker y cuatro en el master. Solo una solicitud activa. El piloto con un hilo por worker se archivó por separado. Se descartó el prototipo KV Q8_0 tras una salida 139 con el fixture; C4 ajusta la distribución de pesos.")
    small("Logs de referencia en logs/oom/, logs/limite-efectivo-2g.txt, logs/piloto/ y logs/compatibilidad-q8-kv/. Cada celda conserva master.log y *-limites.txt.")

    title("Resultados A y B", "Medición")
    p(f"{complete}/8 celdas con tres repeticiones. Cada valor muestra mediana e IQR entre paréntesis. TPOT se deriva como 1000 / tok/s. El SLO exige TTFT ≤ 6 s y TPOT ≤ 150 ms en cada repetición.")
    rows = []
    for c in (f"C{i}-{s}" for i in range(1, 5) for s in "AB"):
        row = data.get(c)
        if not row:
            rows.append([c, "0", "—", "—", "—", "—", "—", "—", "Pend."])
            continue
        def q(field, scalar=1, decimals=2):
            med, iqr = value(row, field), row[field]["iqr"]
            return f"{qty(med*scalar if med is not None else None,decimals)} ({qty(iqr*scalar if iqr is not None else None,decimals)})"
        rows.append([c, str(row["n"]), q("ttft", .001), q("tps"), q("tpot", 1, 1),
                     q("rss", 1/MIB, 0), q("tx", 1/MIB, 1), q("rx", 1/MIB, 1), mark(row)])
    table(["Celda", "n", "TTFT s", "tok/s", "TPOT ms", "RSS MiB", "Tx MiB", "Rx MiB", "SLO"], rows,
          [48, 23, 64, 60, 64, 73, 61, 59, 52])
    chart("metricas-ab", "Figura 2. Comparación A/B. Barras de error de longitud total igual al IQR, centradas en la mediana. VRAM no aplica al Perfil B.", 186)
    small("RSS es el pico sincronizado del conjunto de procesos de inferencia muestreados a 0,5 s. Tx/Rx corresponden al master e incluyen protocolo y RPC. Pre-fill, total y rendimiento efectivo están en resultados.csv. La telemetría de proceso excluye los proxies.")

    title("Red y análisis por fase", "Medición")
    table(["Escenario", "Nominal", "Ping directo, media / mdev", "Pérdida ICMP", "iperf3 directo", "iperf3 por proxy"], [
        [s, ("1 000 Mbps · 0,5 ms · 0 %" if s == "A" else "100 Mbps · 2 ms · 0,1 %"),
         f"{qty(net['rtt'],3)} / {qty(net['mdev'],3)} ms", f"{qty(net['loss'],1)} %",
         f"{qty(net['directo'],1)} Mbps", f"{qty(net['escenario'],1)} Mbps"] for s, net in nets.items()
    ], [61, 121, 111, 66, 72, 73])
    chart("traza-red", f"Figura 3. Serie acumulada del master en {base_config}. Las líneas punteadas marcan el primer token. Resolución de muestreo 0,5 s.", 150)
    cell_a, cell_b = data.get(f"{base_config}-A"), data.get(f"{base_config}-B")
    if cell_a and cell_b:
        pre = value(cell_b, "prefill_ms") / value(cell_a, "prefill_ms")
        dec = value(cell_b, "tpot") / value(cell_a, "tpot")
        a_tx = (value(cell_a, "tx") or 0) + (value(cell_a, "rx") or 0)
        b_tx = (value(cell_b, "tx") or 0) + (value(cell_b, "rx") or 0)
        a_pre = (value(cell_a, "tx_before_first") or 0) + (value(cell_a, "rx_before_first") or 0)
        b_pre = (value(cell_b, "tx_before_first") or 0) + (value(cell_b, "rx_before_first") or 0)
        phase = "prefill" if pre > dec else "decode"
        p(f"En {base_config}, B multiplicó el tiempo de prefill por {qty(pre,2)} y el TPOT por "
          f"{qty(dec,2)} respecto de A. <b>{phase.capitalize()} se degradó más</b> en términos relativos. "
          f"Tx + Rx fue {qty(a_tx/MIB,1)} MiB en A y {qty(b_tx/MIB,1)} MiB en B. "
          f"Antes del primer token se estiman {qty(a_pre/MIB,1)} y {qty(b_pre/MIB,1)} MiB mediante interpolación de los contadores."
          "Un lote de entrada transmite activaciones más voluminosas; el decode encadena operaciones pequeñas con esperas por token.")
    if all(nets[s]["rtt_aplicacion"] is not None for s in "AB"):
        p(f"En el eco TCP de 64 B por el mismo proxy, el RTT mediano fue {qty(nets['A']['rtt_aplicacion'],2)} ms (A) y "
          f"{qty(nets['B']['rtt_aplicacion'],2)} ms (B). Los 100 ecos por escenario se conservaron íntegros.")
    p("El RTT ICMP es del bridge sin proxy y el enlace virtual directo puede superar 1 Gbps. Incluso con netem, 0,5 ms por egreso aporta aproximadamente 1 ms de ida y vuelta más el RTT de base. La tasa útil del proxy baja por serialización por bloque, granularidad de los temporizadores de asyncio, tráfico de control y segmentación de las lecturas.")
    p("En un switch administrable usaría shaping de egreso por puerto y mediría la cola en ambos sentidos. Un policer puede descartar ráfagas por encima de la tasa; el retardo fijo y la pérdida aleatoria requerirían un equipo de emulación. El proxy retarda envíos y omite el control de congestión real de una WAN.")
    if first_record:
        min_prefill = first_record["timings"]["prompt_n"] / 6
        p(f"Un prompt de {first_record['timings']['prompt_n']} tokens requiere al menos {qty(min_prefill,1)} tok/s "
          "de prefill para un TTFT de 6 s incluso antes de contar otras esperas.")
    small("Los registros están en logs/red/netem-intento.txt y en ping.txt, iperf-directo.json, iperf-escenario.json y *-tc.txt de logs/C2-{A,B}/. Los contadores de qdisc no representan pérdida simulada.")

    title("Almacenamiento y arranque", "Memoria y servicio")
    dl = elapsed_download()
    observed_rate = MODEL_BYTES*8/dl/1e6 if dl else None
    p(f"La descarga tardó {qty(dl,1)} s desde la creación hasta el último byte escrito, a {qty(observed_rate,2)} Mbps medios. "
      "La cota ideal es 289,29 s a 100 Mbps y 28,93 s a 1 Gbps; la observación incluye la ruta remota y su disponibilidad de ancho de banda.")
    rows = []
    largest = max((x["pesos"] for x in memory if x["node"] != "master"), default=None)
    for name, tb, price, bw in FUENTES["almacenamiento"]:
        rows.append([name, f"{qty(price/(1000*tb),2)}", f"{qty(bw)}", f"{qty(MODEL_BYTES/(bw*1e6),2)}",
                     qty(largest*MIB/(bw*1e6),2) if largest else "—"])
    table(["Medio", "COP/GB", "MB/s sup.", "GGUF entero (s)", "Shard mayor (s)"], rows, [106, 94, 88, 105, 111])
    disk = LOG / "almacenamiento/lectura-directa.txt"
    if disk.exists():
        reads = re.findall(r"([\d]+) bytes .*? copied, ([\d.]+) s", disk.read_text())
        if reads:
            read_bytes, read_time = int(reads[-1][0]), float(reads[-1][1])
            p(f"Una lectura directa de {qty(read_bytes/1e9,3)} GB en el volumen cloud tardó "
              f"{qty(read_time,2)} s ({qty(read_bytes/read_time/1e6,0)} MB/s). "
              "La medición identifica la ruta virtual de almacenamiento, cuyo medio físico se desconoce.")
    table(["Celda", "Up a /health (s)", "Primer TTFT (s)", "Segundo TTFT (s)"], [
        [f"{base_config}-{s}", *[qty(v,2) for v in info_for(raw,f"{base_config}-{s}")]] for s in "AB"
    ], [108, 132, 132, 132])
    chart("cold-warm", f"Figura 4. TTFT del primer y segundo POST de {base_config}. Los POST comienzan después de cargar el modelo.", 142)
    p("El tiempo del usuario durante un inicio frío incluye espera a /health, cómputo y primera entrega. En un servidor ya disponible, el TTFT cubre el prefill, muestreo y transporte al cliente. El arranque medido incluye Docker, lectura, distribución RPC sin shaping y asignación de KV. Los tiempos por medio son cotas calculadas, porque el soporte físico de la VM no se identificó.")
    p("Para un master que lee el archivo entero y envía todos los shards, estimar t_carga ≈ tamaño / BW del disco y t_RPC ≥ bytes remotos / BW agregado de salida. Algunas fases se solapan. Usaría NVMe para el GGUF activo, SSD SATA para logs y HDD para históricos y checkpoints inactivos. El costo de almacenamiento ya está representado en los equipos de referencia.")
    small("Datos de precio en costos.xlsx. NVMe y HDD consultados en Tauret el 27-11-2026. SATA usa la plantilla UTB. Los anchos de banda son supuestos de lectura secuencial.")

    title("Memoria y concurrencia", "Dimensionamiento")
    local_probe = LOG / "master-local/resultado.txt"
    if local_probe.exists():
        if local_probe.read_text().strip() == "health-ok":
            p("Sin RPC, el Qwen de 3B llegó a /health con 4 GiB y contexto 4K. "
              "Con 2 GiB por proceso, la carga completa falla y la partición es indispensable.")
        else:
            p("El ensayo de carga local en 4 GiB no alcanzó /health. El estado y el motivo de salida se "
              "conservan en logs/master-local/. La prueba de asignación a 2 GiB se validó de forma independiente.")
    p("KV FP16 por token = 2 × 36 × 2 × 128 × 2 B = 36 864 B. Para 2K, 4K y 8K el total por sesión es 72, 144 y 288 MiB. Ocho sesiones a 4K requieren 1 152 MiB solo para KV. El presupuesto inicial y sus reservas están en prelab.md.")
    chart("memoria", f"Figura 5. {memory_cell}. El residuo RSS incluye runtime, activaciones y memoria transitoria de carga. El fondo libre se dibuja respecto del límite AS; para capacidad se usa VmSize.", 120)
    mem_rows = []
    bounds = []
    for node in memory:
        context = 4096
        kv_per_token = node["kv"]*MIB/context
        headroom = max(0, node["limite"]-node["virtual_pico"])
        max_ctx = math.floor(context+headroom*MIB/kv_per_token) if kv_per_token else None
        sessions = math.floor(max_ctx/context) if max_ctx is not None else "—"
        if isinstance(sessions, int):
            bounds.append(sessions)
        mem_rows.append([node["node"], qty(node["pesos"],1), qty(node["kv"],1),
         qty(node["rss_pico"],1), qty(node["virtual_pico"],1), qty(headroom,1),
         qty(max_ctx), str(sessions)])
    table(["Proceso", "Pesos MiB", "KV MiB", "Pico RSS", "Pico VSZ", "Margen AS", "Ctx por KV", "Ses. 4K"],
          mem_rows, [75, 58, 54, 65, 63, 65, 70, 54])
    if bounds:
        p(f"El mínimo observado permite estimar hasta {min(bounds)} sesiones de 4K por presupuesto KV solamente. "
          "El contexto estimado suma 4096 tokens a la capacidad del margen virtual restante, usando el KV medido por proceso. "
          "El límite nativo por sesión es 32 768. Los costes adicionales de slots, batching y trabajo del master reducen esa capacidad.")
    weighted = node_memory("C4-A")
    equal = node_memory("C2-A")
    if weighted and equal:
        w3 = next(n for n in weighted if n["node"] == "worker-3")
        e3 = next(n for n in equal if n["node"] == "worker-3")
        p(f"El reparto ponderado descargó el último worker de {qty(e3['pesos'],1)} a {qty(w3['pesos'],1)} MiB. "
          "Parte del peso y KV se trasladó a los primeros workers. El efecto sobre la latencia se comprueba en la Figura 2.")
    two_workers = node_memory("C3-A")
    if two_workers:
        tight = min((n for n in two_workers if n["node"].startswith("worker")),
                    key=lambda n: n["limite"]-n["virtual_pico"])
        p(f"En C3-A, {tight['node']} quedó con {qty(tight['limite']-tight['virtual_pico'],1)} MiB de margen "
          "virtual. Concentrar capas en dos workers reduce la holgura para buffers y futuras sesiones.")
    p("La demanda media de salida es 5,21 tok/s y el pico de diseño es 900 tok/s mientras llegan tres solicitudes de 300 tokens por segundo. Con una sola sesión medida, más slots pueden ganar rendimiento agregado y aumentar cola o TPOT. La ejecución serial no absorbe ese pico. Aplicaría admisión y cola para ráfagas, y derivaría trabajos largos a ejecución asíncrona. Se requiere una prueba concurrente para dimensionar el máximo admitido.")
    small("El RSS se toma de /proc/1/status. Los pesos y KV corresponden a los buffers de llama.cpp.")

    title("Costo, utilización y alternativas", "Economía")
    p("TCO nominal = CAPEX + 3 × OPEX de caja. En el clúster, los rubros de caja son energía, conectividad y mantenimiento. Se muestra depreciación en la hoja de costos para contabilidad. Los activos existentes reducen el desembolso incremental a UPS e instalación.")
    cluster_price = model["tco"]/(years*demand/1e6)
    gpu_price = gpu["tco"]/(years*demand/1e6)
    cash_rows = [
        ["Clúster CPU", qty(model["capex"]), qty(model["opex"]), qty(model["tco"]), qty(model["tps"],2), qty(cluster_price), "Local"],
        ["RTX 3090", qty(gpu["capex"]), qty(gpu["opex"]), qty(gpu["tco"]), qty(gpu["tps"],2), qty(gpu_price), "Local"],
    ]
    for api in cost["api"]:
        cash_rows.append([api["name"], "0", qty(api["cop"]*demand/1e6),
                          qty(api["cop"]*demand*years/1e6), "—", qty(api["cop"]), "Remota"])
    table(["Opción", "CAPEX", "OPEX/año", "TCO 3a", "tok/s", "COP/1M", "Datos"], cash_rows,
          [121, 67, 70, 70, 50, 71, 55])
    small("COP/1M a demanda teórica de 37,5 M de salida/año. Las APIs suman el costo de un token de entrada por cada token de salida, sin caché. El rendimiento del clúster es de servicio completo; la GPU es una hipótesis de decode.")
    cap = cost["annual_capacity"]
    if cap:
        p(f"En {baseline}, la capacidad teórica al 100 % es {qty(cap/1e6,2)} M tokens/año. "
          f"La demanda representa {qty(100*demand/cap,1)} % de esa capacidad de una sola sesión. "
          f"Los costos por millón a 25 %, 50 % y 100 % son COP "
          f"{qty(model['tco']/(years*cap*.25/1e6))}, {qty(model['tco']/(years*cap*.5/1e6))} y "
          f"{qty(model['tco']/(years*cap/1e6))}. La disponibilidad y la estacionalidad reducen la producción sostenible.")
    if baseline and f"{base_config}-B" in data and data[f"{base_config}-B"]["n"] == 3:
        cap_b = value(data[f"{base_config}-B"], "service_tps") * cost["hours"] * 3600
        p(f"En B, la misma configuración produciría {qty(cap_b/1e6,2)} M/año al 100 %. "
          + (f"El déficit respecto de la demanda es {qty((demand-cap_b)/1e6,2)} M." if cap_b < demand
             else "La capacidad anual supera la demanda bajo los supuestos de una sesión."))
    p(f"Techo GPU para lote 1 = min(936,2 GB/s ÷ (3,616 GB + 144 MiB), 35,58 TFLOP/s ÷ (2 × 3,09 G)) = "
      f"{qty(gpu['roofline'],1)} tok/s. Se aplica 25 % de eficiencia supuesta y se obtiene {qty(gpu['tps'],1)} tok/s. "
      "Prefill, concurrencia, potencia y latencia de GPU única quedan por medir. El precio de COP 14 M es un presupuesto de la plantilla.")
    chart("pareto", "Figura 6. Pareto a 50 % de utilización para un mismo CAPEX de cuatro nodos. Círculo = SLO, cruz = falla. El eje x descuenta el costo de prefill.", 172)
    small(source(FUENTES["fuentes_locales"]["GPU"], "Especificación NVIDIA") + " · " +
          source(FUENTES["fuentes_locales"]["TRM"], "TRM oficial") + " · " +
          " · ".join(source(api["url"], api["name"]) for api in cost["api"]))

    title("Punto de equilibrio y sensibilidad", "Economía")
    chart("break-even", "Figura 7. COP por millón frente al volumen anual. Las líneas locales punteadas extrapolan volúmenes por encima de la capacidad calculada.", 220)
    rows = []
    for api in cost["api"]:
        tokens = model["tco"] * 1e6 / (years*api["cop"])
        rows.append([api["name"], qty(api["cop"]), qty(tokens/1e6,1), qty(tokens/(cost["hours"]*3600),1),
                     ("Sí" if tokens <= cap else "No") if cap else "Pendiente"])
    table(["API", "COP/1M", "Equilibrio M/año", "Tok/s requeridos", "Alcanzable"], rows,
          [155, 77, 102, 100, 70])
    low_energy = (model["tco"]-years*.25*model["energy"])/(years*demand/1e6)
    high_energy = (model["tco"]+years*.25*model["energy"])/(years*demand/1e6)
    table(["Cambio", "Efecto aislado", "Criterio"], [
       ("Tarifa 600 / 800 / 1 000 por kWh", f"COP {qty(low_energy)} / {qty(cluster_price)} / {qty(high_energy)} por 1M", "Demanda fija"),
       ("Utilización 25 / 50 / 100 %", "4× / 2× / 1× del costo a plena capacidad", "Potencia y TCO constantes"),
       ("Throughput −30 % / +30 %", "1,429× / 0,769× del COP/1M", "Utilización constante"),
       ("Tarifa API −50 % / +50 %", "2× / 0,667× del volumen de equilibrio", "Mismo volumen de entrada y salida"),
    ], [172, 206, 126])
    p("El precio por millón sube rápidamente con horas ociosas. La utilización no rescata un equipo con un rendimiento insuficiente para el volumen comprometido. La API referencia el costo variable, pero su ruta remota incumple la privacidad.")
    small(f"Se aplicó una TRM de COP {qty(FUENTES['trm_cop_usd'],2)}/USD, vigencia 26–27 de noviembre de 2026. Precios API consultados el 27 de noviembre, excluyendo impuestos, herramientas y créditos.")

    title("Escalabilidad y decisión final", "Análisis de arquitectura")
    sub("Etapas, velocidad y punto de cruce")
    p("El offload de llama.cpp reparte grupos contiguos de capas mediante split por capas. Cada token recorre las etapas en orden. Con varios microbatches puede haber solapamiento, limitado por la etapa más lenta. Un split tensorial dentro de cada capa exige intercambios y reducciones más frecuentes, con mayor dependencia de latencia y ancho de banda.")
    if baseline:
        r = data[baseline]
        network_bytes = sum(
            (value(r, field) or 0) - (value(r, f"{field}_before_first") or 0)
            for field in ("tx", "rx")
        ) / max(1, value(r,"tokens")-1)
        native_tpot = value(r,"tpot")
        bw_a = nets["A"]["escenario"]
        transfer_ms = 8*network_bytes/(bw_a*1e6)*1000 if bw_a else 0
        serial_tpot = max(0.001,native_tpot-transfer_ms)
        crossover = 8*network_bytes/(serial_tpot/1000)/1e6
        faster_tpot = serial_tpot+8*network_bytes/1e10*1000
        upgrade_price = 4*FUENTES["nic_10gbe_cop"]+FUENTES["switch_10gbe_cop_supuesto"]
        gain = max(0,1000/faster_tpot-1000/native_tpot)
        p(f"En {baseline}, la traza equivale a {qty(network_bytes/1024,1)} KiB por token de salida después del primer token. "
          f"El modelo aditivo t ≈ t_fijo + 8D/BW aproxima {qty(transfer_ms,2)} ms de transmisión a la tasa útil de A, "
          f"y {qty(serial_tpot,2)} ms de cómputo, latencia y sincronización remanentes. El cruce 8D/t_fijo es "
          f"{qty(crossover,1)} Mbps. La cota ilustrativa a 10 Gbps es {qty(1000/faster_tpot,2)} tok/s; "
          "la RTT y las esperas de protocolo permanecen en el término fijo.")
        p(f"Un paquete de cuatro NIC y switch 10 GbE costaría COP {qty(upgrade_price)} antes de instalación y elevaría "
          f"el TCO a COP {qty(model['tco']+upgrade_price*(1+years*cost['op']['mantenimiento']))} "
          f"con 5 % de mantenimiento anual. La mejora aditiva es {qty(gain,2)} tok/s. "
          + (f"Esto equivale a COP {qty(upgrade_price/gain)} por tok/s adicional." if gain > 0 else ""))
    bw = LOG / "cpu/bw-4.json"
    if bw.exists() and baseline:
        speed = median(json.loads(bw.read_text())["muestras_gb_s"])
        memory_roof = speed * 1e9 / (MODEL_BYTES + 4096 * 36864)
        p(f"La microprueba de lectura de 768 MiB con cuatro hilos entregó {qty(speed,1)} GB/s "
          f"y una cota de memoria de {qty(memory_roof,1)} tok/s con pesos más KV 4K. "
          f"El decode observado alcanza {qty(100*value(data[baseline],'tps')/memory_roof,1)} % de esa cota. "
          "La lectura secuencial en un host no reproduce el tráfico de tensores ni los límites de cómputo RPC.")
    p("Amdahl con un supuesto ilustrativo del 30 % escalable y 7/3 veces más workers da 1/(0,70 + 0,30×3/7) = 1,21× antes de añadir mensajes. Más workers aumentan la capacidad de pesos. En decode secuencial, memoria, sincronización y el puerto compartido condicionan la velocidad.")
    sub("Prioridad de inversión y validación")
    p(f"La GPU única elimina los intercambios RPC y concentra cómputo y pesos. Su TCO modelado supera al clúster por COP "
      f"{qty(gpu['tco']-model['tco'])} en reposición. Si la infraestructura existente está disponible, evaluar con su costo incremental. "
      "El clúster tiene sentido para investigación o trabajo local asincrónico si el período ocupado, el modelo autorizado y la capacidad medida lo justifican.")
    p("Para evitar CAPEX prematuro, el piloto puede usar la RTX 3060 existente con Qwen2.5-7B-Instruct Q4_K_M, "
      "Apache 2.0. Sus dos archivos suman 4,683 GB. El margen de VRAM debe verificarse con KV, temporales y carga concurrente. "
      "Se requiere comparar calidad de respuestas en español antes de cambiar cuantización. " +
      source("https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF/tree/bb5d59e06d9551d752d08b292a50eb208b07ab1f",
             "Modelo alternativo y licencia"))
    if baseline and gpu["tps"] > value(data[baseline], "tps"):
        speed_gain = gpu["tps"] - value(data[baseline], "tps")
        p(f"La diferencia de reposición equivale a COP "
          f"{qty((gpu['tco']-model['tco'])/speed_gain)} por tok/s adicional de decode proyectado "
          f"(+{qty(speed_gain,1)} tok/s). Este cociente combina una medición CPU con una proyección GPU y debe verificarse en el piloto.")
    p("En un clúster físico mediría potencia en pared, RAM y VRAM por nodo, NIC, latencia y pérdidas reales, prefill/decode y percentiles bajo ráfagas, además de recuperación ante fallo de master y worker. La meta del 99 % permite como máximo 20 h de caída por 2 000 h laborales. Los resultados de un solo host con ruido de CPU y un proxy por flujo requieren esa validación.")
    small("Reproducción y declaración de IA en README.md. Fuentes experimentales en logs/. La referencia de arquitectura es Patterson y Hennessy, Computer Organization and Design RISC-V, 2.ª ed., capítulos 4–6.")

    title("Reproducción y trazabilidad", "Anexo")
    p("Las rutas son relativas a entrega/. Los registros crudos se mantienen separados de las figuras y tablas derivadas. La cadena de métricas comienza con 64 ceros y cada registro incluye el SHA-256 de la línea anterior.")
    table(["Qué verificar", "Archivo o carpeta"], [
        ("Versión y hardware", "logs/entorno.txt"),
        ("Identidad del GGUF", "logs/modelo.txt y prelab.md"),
        ("Límite de 2 GiB y error de asignación", "logs/oom/oom.log, oom-exit.txt y oom-estado.txt"),
        ("Topología, modelos, KV y límites", "logs/C*-*/compose-ps.txt, master.log, worker-*.log y *-limites.txt"),
        ("Arranque y repeticiones", "logs/C*-*/inicio.json, warmup.jsonl y corridas.jsonl"),
        ("Pruebas adicionales de memoria", "logs/master-local/ y logs/estricto/"),
        ("TTFT, decode, prefill y hashes", "logs/metricas.jsonl, resultados.csv y resumen.json"),
        ("Red A/B y soporte del kernel", "logs/red/ y logs/C2-{A,B}/"),
        ("TCO y entradas auditables", "costos.xlsx, codigo/fuentes.json y logs/fuentes/"),
        ("Comandos de réplica", "README.md, codigo/ejecutar.py, codigo/config.json y codigo/oom.sh"),
    ], [191, 313])
    sub("Validación del protocolo")
    p("El analizador verifica hashes, etiquetas y el límite de 300 tokens antes de agregar resultados. El verificador contrasta el número de repeticiones, la caché desactivada, límites y buffers positivos en cada worker. Las medianas e IQR se reconstruyen directamente desde logs/metricas.jsonl.")
    sub("Declaración de uso de IA")
    p("Se usó Codex para programar y depurar el montaje, ejecutar y verificar los experimentos, consultar precios y redactar el informe. Las mediciones se conservan con sus timestamps. La defensa oral y la validación de la entrega corresponden al estudiante.")

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#BDD0D6"))
        canvas.line(54, 48, 558, 48)
        canvas.setFillColor(MUTED)
        canvas.setFont("Regular", 8)
        canvas.drawString(54, 32, "UTB  /  Arquitectura de computadores  /  Perfil B")
        canvas.drawRightString(558, 32, str(doc.page))
        canvas.restoreState()

    doc = SimpleDocTemplate(str(ROOT / "informe.pdf"), pagesize=letter,
                            leftMargin=54, rightMargin=54, topMargin=49, bottomMargin=60,
                            title="Clúster distribuido de inferencia LLM", author="Entrega de laboratorio")
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


if __name__ == "__main__":
    produce()
