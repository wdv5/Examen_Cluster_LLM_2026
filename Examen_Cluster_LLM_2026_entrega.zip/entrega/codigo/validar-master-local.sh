#!/usr/bin/env bash
set -euo pipefail
bin=$(realpath "$1")
model=$(realpath "$2")
log_dir=$(realpath -m "$3")
mkdir -p "$log_dir"
container=$(docker run -d --memory 4g --memory-swap 4g --network none \
  -e OMP_WAIT_POLICY=PASSIVE -e MALLOC_ARENA_MAX=2 \
  -v "$bin:/llama-bin:ro" -v "$model:/model.gguf:ro" \
  examen-cluster-cpu:trixie prlimit --as=4294967296:4294967296 /llama-bin/llama-server \
  --model /model.gguf --no-mmap --fit off --ctx-size 4096 --parallel 1 \
  --threads 4 --host 127.0.0.1 --port 8080 --no-ui --log-verbosity 4)
trap 'docker rm -f "$container" >/dev/null' EXIT
outcome=tiempo-agotado
for ((i=0;i<60;i++)); do
  if [[ "$(docker inspect --format '{{.State.Running}}' "$container")" == false ]]; then
    outcome=salio-antes-de-health
    break
  fi
  if docker exec "$container" curl -fsS --max-time 1 http://127.0.0.1:8080/health > "$log_dir/health.json" 2>/dev/null; then
    outcome=health-ok
    docker exec "$container" cat /proc/1/limits /proc/1/status > "$log_dir/proceso.txt"
    break
  fi
  sleep .5
done
printf '%s\n' "$outcome" > "$log_dir/resultado.txt"
docker inspect --format '{{json .State}}' "$container" > "$log_dir/estado.json"
docker logs --timestamps "$container" > "$log_dir/master-local.log" 2>&1
cat "$log_dir/resultado.txt"
