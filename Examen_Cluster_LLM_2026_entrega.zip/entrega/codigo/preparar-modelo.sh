#!/usr/bin/env bash
set -euo pipefail
target_dir=${1:-"$PWD/modelos"}
mkdir -p "$target_dir"
cd "$target_dir"
model=qwen2.5-3b-instruct-q8_0.gguf
revision=7dabda4d13d513e3e842b20f0d435c732f172cbe
checksum=6dcc22694c8654b045ec40bbe350212b88893fd9010e8474bae5b19a43578ba1
if [[ ! -f "$model" ]]; then
  curl --fail --location --retry 2 --output "$model.part" \
    "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/$revision/$model?download=true"
  printf '%s  %s\n' "$checksum" "$model.part" | sha256sum -c -
  mv "$model.part" "$model"
else
  printf '%s  %s\n' "$checksum" "$model" | sha256sum -c -
fi
stat -c '%s bytes %n' "$model"
