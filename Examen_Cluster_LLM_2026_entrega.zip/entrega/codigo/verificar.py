"""Comprueba que la entrega coincide con los artefactos experimentales."""
import argparse
import json

from analizar import ROOT, LOG, metrics, node_memory


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--parcial", action="store_true")
    partial = parser.parse_args().parcial
    results = metrics()
    expected = {f"C{i}-{scenario}" for i in range(1, 5) for scenario in "AB"}
    completed = set()
    for cell, rows in results.items():
        reps = {r["config"]["repetition"] for r in rows}
        expected_workers = rows[0]["config"]["workers"]
        if reps != {1, 2, 3}:
            continue
        shards = [p for p in node_memory(cell) if p["node"].startswith("worker-")]
        assert len(shards) == expected_workers and all(p["pesos"] > 0 for p in shards), cell
        assert all(p["virtual_pico"] <= p["limite"] for p in shards), cell
        assert all(r["timings"]["cache_n"] == 0 for r in rows), cell
        completed.add(cell)
    assert set(results) <= expected, set(results) - expected
    if not partial:
        assert completed == expected, sorted(expected - completed)
        assert sum(len(r) for r in results.values()) == 24
    state = json.loads((LOG / "oom/oom-estado.txt").read_text().splitlines()[-1])
    oom = (LOG / "oom/oom.log").read_text()
    assert state["ExitCode"] and "failed to allocate buffer of size 3610132480" in oom
    assert all((ROOT / p).stat().st_size for p in (
        "informe.pdf", "prelab.md", "costos.xlsx", "README.md", "resultados.csv"))
    if not partial:
        strict = LOG / "estricto"
        if (strict / "metricas.jsonl").exists():
            extra = strict / "C2-A"
            for node in ("master", "worker-1", "worker-2", "worker-3"):
                limit_line = next(
                    line for line in (extra / f"{node}-limites.txt").read_text().splitlines()
                    if "Max address space" in line
                )
                assert limit_line.split()[-3:-1] == ["2147483648", "2147483648"], node
            r = json.loads((strict / "metricas.jsonl").read_text().strip())
            assert r["n_tokens"] == 8
    print(f"{len(completed)}/8 celdas completas; {sum(len(r) for r in results.values())} registros válidos.")
    print("SHA enlazados, partición, réplica, límites efectivos y fallo de asignación comprobados.")


if __name__ == "__main__":
    main()
