"""Valida la cadena cruda y resume las corridas del examen."""
from collections import defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
from statistics import median, quantiles

ROOT = Path(__file__).resolve().parent.parent
LOG = ROOT / "logs"
MIB = 1024**2
GIB = 1024**3
MODEL_BYTES = 3_616_088_480
PARAMS = 3.09e9
KV_BYTES = 2 * 36 * 2 * 128 * 2
FUENTES = json.loads((ROOT / "codigo/fuentes.json").read_text())


def lines(path):
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def metrics():
    path = LOG / "metricas.jsonl"
    previous = "0" * 64
    groups = defaultdict(list)
    if not path.exists():
        return groups
    for line in path.read_text().splitlines():
        record = json.loads(line)
        assert record["prev_hash"] == previous, record["label"]
        actual = record.pop("hash")
        canonical = json.dumps(record, sort_keys=True, ensure_ascii=False).encode()
        assert actual == hashlib.sha256(canonical).hexdigest(), record["label"]
        previous = hashlib.sha256(line.strip().encode()).hexdigest()
        assert record["n_predict"] == 300 and record["n_tokens"] > 0
        key = f"{record['config']['name']}-{record['scenario']}"
        assert not any(x["label"] == record["label"] for x in groups[key])
        groups[key].append(record)
    return groups


def sample_delta(samples, start, end, field):
    if len(samples) < 2 or end <= start:
        return None

    def estimate(t):
        if t <= samples[0]["epoch"]:
            return samples[0][field]
        for left, right in zip(samples, samples[1:]):
            if right["epoch"] >= t:
                frac = (t - left["epoch"]) / (right["epoch"] - left["epoch"])
                return left[field] + frac * (right[field] - left[field])
        return samples[-1][field]

    return round(estimate(end) - estimate(start))


def stats(numbers):
    values = [x for x in numbers if x is not None]
    if not values:
        return {"median": None, "iqr": None}
    quartiles = quantiles(values, n=4, method="inclusive") if len(values) > 1 else None
    return {"median": median(values), "iqr": quartiles[2] - quartiles[0] if quartiles else None}


def value(row, field):
    return row[field]["median"]


def cell_summary(cell, rows):
    directory = LOG / cell
    host = lines(directory / "master-telemetria.jsonl")
    by_metric = defaultdict(list)
    for record in rows:
        end = datetime.fromisoformat(record["timestamp"]).timestamp()
        start = end - record["total_ms"] / 1000
        first = start + record["ttft_ms"] / 1000
        by_metric["ttft"].append(record["ttft_ms"])
        by_metric["tps"].append(record["gen_tps"])
        by_metric["tpot"].append(1000 / record["gen_tps"])
        by_metric["prefill"].append(record["prompt_tps"])
        by_metric["prefill_ms"].append(record["prompt_ms"])
        by_metric["total_ms"].append(record["total_ms"])
        by_metric["tokens"].append(record["n_tokens"])
        by_metric["service_tps"].append(1000 * record["n_tokens"] / record["total_ms"])
        for field in ("tx", "rx"):
            by_metric[field].append(sample_delta(host, start, end, field))
            by_metric[f"{field}_before_first"].append(sample_delta(host, start, first, field))
        by_metric["rss"].append(peak_rss(directory, start, end))
    summary = {field: stats(values) for field, values in by_metric.items()}
    summary["n"] = len(rows)
    summary["slo"] = all(r["ttft_ms"] <= 6000 and r["gen_tps"] >= 1000 / 150 for r in rows)
    return summary


def peak_rss(directory, start, end):
    traces = [lines(trace) for trace in sorted(directory.glob("*telemetria.jsonl"))]
    traces = [trace for trace in traces if trace and "VmRSS" in trace[0]]
    if not traces:
        return None
    peak = 0
    for clock in traces[0]:
        t = clock["epoch"]
        if start - 0.5 <= t <= end + 0.5:
            synchronized = [min(samples, key=lambda x: abs(x["epoch"] - t)) for samples in traces]
            peak = max(peak, sum(sample["VmRSS"] for sample in synchronized))
    return peak or None


def node_memory(cell):
    directory = LOG / cell
    source = directory / "master.log"
    if not source.exists():
        return []
    text = source.read_text()
    devices = {f"worker-{i}": f"worker-{i}:50052" for i in range(1, 4)}
    result = []
    for node in ("master", *devices):
        trace = lines(directory / f"{node}-telemetria.jsonl")
        if not trace:
            continue
        if node == "master":
            matcher = r"\bCPU(?:_Mapped)?\b"
            limit = 4096
        else:
            matcher = rf"RPC\d+\[{re.escape(devices[node])}\]"
            limit = 2048
        weights = re.findall(rf"{matcher}\s+model buffer size\s*=\s*([\d.]+) MiB", text)
        kv = re.findall(rf"{matcher}\s+KV buffer size\s*=\s*([\d.]+) MiB", text)
        if not kv:
            kv = re.findall(rf"{matcher}\s+KV self size\s*=\s*([\d.]+) MiB", text)
        peak = max(sample["VmHWM"] for sample in trace) / MIB
        weights = sum(map(float, weights))
        kv = sum(map(float, kv))
        result.append({
            "node": node, "pesos": weights, "kv": kv, "rss_pico": peak, "limite": limit,
            "runtime": max(0.0, peak - weights - kv), "libre": limit - peak,
            "virtual_pico": max(sample["VmSize"] for sample in trace) / MIB,
        })
    return result


def prices(tps):
    op = FUENTES["operacion"]
    capex = sum(quantity * unit for _, quantity, unit, _ in FUENTES["capex"])
    demand = op["solicitudes_dia"] * op["tokens_salida"] * op["dias_año"]
    hours = op["horas_dia"] * op["dias_año"]
    def local(cap, watts):
        energy = watts / 1000 * hours * op["tarifa_kwh"]
        opex = energy + 12 * op["internet_mes"] + cap * op["mantenimiento"]
        return {"capex": cap, "watts": watts, "energy": energy, "opex": opex,
                "tco": cap + op["años"] * opex}
    cluster = local(capex, op["potencia_cluster_w"])
    gpu = local(FUENTES["capex_gpu"], op["potencia_gpu_w"])
    gpu["roofline"] = min(
        FUENTES["gpu_bandwidth_gb_s"] * 1e9 / (MODEL_BYTES + KV_BYTES * 4096),
        FUENTES["gpu_tflops_fp32"] * 1e12 / (2 * PARAMS),
    )
    gpu["tps"] = gpu["roofline"] * FUENTES["gpu_fraction_bw"]
    cluster["tps"] = tps
    ratio = op["tokens_entrada"] / op["tokens_salida"]
    apis = [
        {"name": label, "in": cost_in, "out": cost_out, "url": url,
         "cop": (cost_in * ratio + cost_out) * FUENTES["trm_cop_usd"]}
        for label, cost_in, cost_out, url in FUENTES["api"]
    ]
    return {"op": op, "demand": demand, "hours": hours, "cluster": cluster, "gpu": gpu,
            "api": apis, "annual_capacity": tps * hours * 3600 if tps else None}


def summarize():
    raw = metrics()
    return {cell: cell_summary(cell, records) for cell, records in sorted(raw.items())}


if __name__ == "__main__":
    data = summarize()
    print(json.dumps(data, ensure_ascii=False, indent=2))
