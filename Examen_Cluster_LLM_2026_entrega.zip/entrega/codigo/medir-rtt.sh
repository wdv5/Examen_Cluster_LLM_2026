#!/usr/bin/env bash
set -euo pipefail
code=$(cd "$(dirname "$0")" && pwd)
evidencia=$(realpath -m "$1")
mkdir -p "$evidencia"

network=$(docker network create --internal examen-utb-rtt)
worker=
cleanup() {
  if [[ -n "$worker" ]]; then docker rm -f "$worker" >/dev/null; fi
  docker network rm "$network" >/dev/null
}
trap cleanup EXIT
worker=$(docker run -d --network "$network" --network-alias eco -v "$code:/lab:ro" \
  examen-cluster-cpu:trixie sh -ec '
    python3 /lab/rtt_tcp.py --server --host 0.0.0.0 --port 5203 &
    python3 -u /lab/proxy_tcp.py --listen-port 5204 --target-port 5203 --delay-ms .5 --rate-mbps 1000 --loss 0 &
    python3 -u /lab/proxy_tcp.py --listen-port 5205 --target-port 5203 --delay-ms 2 --rate-mbps 100 --loss .001 &
    touch /tmp/emular-red
    wait
  ')
for mode in directo A B; do
  case "$mode" in directo) port=5203 ;; A) port=5204 ;; B) port=5205 ;; esac
  docker run --rm --network "$network" -v "$code:/lab:ro" examen-cluster-cpu:trixie \
    python3 /lab/rtt_tcp.py --host eco --port "$port" > "$evidencia/rtt-$mode.json"
done
docker logs --timestamps "$worker" > "$evidencia/rtt-proxy.log" 2>&1
