# Entrega · Clúster distribuido de inferencia LLM

La solución se elaboró para el Perfil B con el modelo Qwen2.5-3B-Instruct Q8_0. La entrega incluye [informe.pdf](informe.pdf), [prelab.md](prelab.md), [costos.xlsx](costos.xlsx), [figuras](figuras) y [logs](logs). El enunciado original y sus recursos se conservan en el directorio superior.

## Entorno

- Linux x86-64, CPU AMD EPYC 9V74, cuota visible de 4 vCPU y 32 GiB de memoria global.
- Docker con Compose v2, red bridge interna `10.0.50.0/24`. Master `.11`, workers `.12`–`.14`. No se publica el puerto RPC.
- `llama.cpp` b9870, commit `2d973636e292ee6f75fadcf08d29cb33511f509f`, backend CPU/RPC. El binario RPC de esta versión se llama `ggml-rpc-server`.
- El runtime del host muestra 32 GiB de `memory.max` aun cuando `docker inspect` declara un límite menor. Los procesos aplican 4 GiB (master) o 2 GiB (workers) vía `RLIMIT_AS`. Los picos se miden con `VmRSS`/`VmHWM`, ya que `docker stats` de este host refleja contadores compartidos.
- El kernel devuelve `Specified qdisc kind is unknown` para `netem`. El modo ensayado fue `proxy`. Establece retardo por bloque y por sentido, serialización a la tasa nominal y demora adicional con una probabilidad de retransmisión basada en segmentos de 1460 B. El proxy conserva los bytes del protocolo, así que las pérdidas emuladas carecen de equivalencia directa con descartes del kernel o control de congestión TCP. El ping ICMP mide el bridge directo. iperf3 mide el bridge y el camino por el proxy por separado.
- El resultado de capacidad local se limita a una solicitud activa. Los logs marcan cada repetición y contienen límites, pesos, red y memoria.

## Reproducción

Desde `entrega/codigo`, en Debian 13 x86-64 con Docker, Compose, Git, Python 3 con venv, compilador C/C++, Make y cabeceras OpenSSL:

```bash
bash preparar-binarios.sh
bash preparar-modelo.sh
docker build -t examen-cluster-cpu:trixie .
bin="$PWD/dependencias/llama.cpp/build/bin"
modelo="$PWD/modelos/qwen2.5-3b-instruct-q8_0.gguf"
evidencia="$(mktemp -d)"
bash oom.sh "$bin" "$modelo" "$evidencia/oom"
python3 ejecutar.py --bin "$bin" --model "$modelo" --logs "$evidencia" --celdas C2-A C2-B
```

Omite `--celdas` para ejecutar la matriz completa. Cada celda reinicia sus contenedores, solicita al SO liberar caché del archivo, hace un calentamiento y mide tres repeticiones. El proxy se activa tras `/health` para separar el costo de arranque del experimento de inferencia. El cliente conserva el texto de `prompt.txt`, usa temperatura 0, semilla 42, streaming, máximo 300 tokens y desactiva la reutilización del prompt.

`--transport tc` selecciona las reglas nativas en un host con `sch_netem`. Ese modo aplica la regla también durante el arranque. En esta VM se verificó que el módulo falta. Los archivos Docker de codigo/ corresponden al montaje CPU ensayado. Las referencias CUDA originales permanecen en recursos/.

Para regenerar el informe y el libro, instala ReportLab, Matplotlib, NumPy y XlsxWriter en un entorno virtual y ejecuta `python3 producir.py` desde `codigo/`. El generador lee `entrega/logs`, verifica la cadena SHA-256 y escribe los entregables y las tablas resumen. Los artefactos originales están en [logs](logs). El modelo se descarga aparte por su tamaño. Usa `python3 verificar.py` para verificar las 24 métricas y sus hashes.

La prueba complementaria de partición estricta usa `--master-gib 2 --tokens 8 --repeticiones 1 --red-config ninguno --celdas C2-A` con un directorio de logs nuevo. Todos los procesos quedan limitados a 2 GiB. Sus logs están separados de la matriz de 300 tokens. El ensayo local sin RPC en 4 GiB alcanzó `/health`; se conserva por separado en `logs/master-local/`.

## Evidencia y limitaciones

- `logs/modelo.txt` contiene fecha, tamaño y SHA-256 verificados.
- `logs/oom/` registra la denegación real de una reserva de 3 610 132 480 B en el proceso limitado a 2 GiB. El asignador terminó con código 1, `OOMKilled=false`.
- `logs/red/netem-intento.txt` muestra el intento de `tc`. Cada directorio experimental conserva estado de Compose, límites, logs RPC, telemetría y métricas de arranque. C2 contiene ping e iperf3.
- El prototipo de caché KV Q8_0 con un modelo sintético salió con código 139; se mantuvo FP16 para las pruebas Qwen y C4 usa un split moderadamente ponderado.
- La GPU única se dimensiona mediante roofline, el consumo eléctrico se presupuesta y las tarifas de API se consultaron con la TRM del día. Las fuentes se conservan en `logs/fuentes/` y `codigo/fuentes.json`.
- Qwen2.5-3B está bajo Qwen Research License. La investigación del laboratorio es el uso contemplado. La operación comercial debe contar con licencia de Alibaba Cloud o con un modelo apto para ese uso. [Licencia](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/blob/7dabda4d13d513e3e842b20f0d435c732f172cbe/LICENSE)

## Uso de IA

Se usó Codex para programar y depurar el banco de pruebas, ejecutar experimentos en el entorno, verificar los logs, consultar precios y redactar el informe. Las cifras empíricas se pueden recomputar desde los datos crudos. Las hipótesis de costos y estimaciones de GPU tienen entradas editables. La defensa oral queda a cargo del estudiante.
