# Pre-lab · Inferencia distribuida con Qwen2.5-3B

**Perfil B adaptado.** El host cloud tiene CPU x86-64, una cuota de cuatro vCPU y carece de GPU NVIDIA. Se usan un coordinador de hasta 4 GiB y tres workers de hasta 2 GiB por proceso (`RLIMIT_AS`). Docker aísla la topología y los procesos. El GGUF ocupa más que el límite de cualquier worker y cabe en su memoria agregada. El coordinador de 4 GiB tiene un presupuesto distinto y puede alojar los pesos en principio. La prueba eliminatoria del Perfil B se realiza en un proceso con el límite de un worker.

## 1. Modelo y descarga

| Propiedad | Valor |
|---|---|
| Archivo | `qwen2.5-3b-instruct-q8_0.gguf` |
| Revisión | `7dabda4d13d513e3e842b20f0d435c732f172cbe` |
| Tamaño exacto | 3 616 088 480 B = 3,616 GB = 3,368 GiB |
| SHA-256 | `6dcc22694c8654b045ec40bbe350212b88893fd9010e8474bae5b19a43578ba1` |
| Licencia | Qwen Research License para evaluación e investigación. La operación comercial requiere una licencia de Alibaba Cloud. |
| Transferencia ideal | 289,29 s a 100 Mbps. 28,93 s a 1 Gbps. Fórmula `8 × bytes / bits/s`. |

El hash y el tamaño se contrastan con [la revisión del modelo](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/tree/7dabda4d13d513e3e842b20f0d435c732f172cbe). La evidencia local está en [logs/modelo.txt](logs/modelo.txt). [Licencia del artefacto](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/blob/7dabda4d13d513e3e842b20f0d435c732f172cbe/LICENSE)

## 2. Presupuesto de memoria

Pesos teóricos con todos los tensores Q8_0: `3,09×10⁹ × (32 + 2) / 32 = 3 283 125 000 B`. El bloque contiene 32 enteros de 8 bits y una escala FP16. Para dimensionar uso los bytes del GGUF, que además contiene tensores de otros tipos, vocabulario, metadatos y alineación. Los buffers reales pueden duplicar embeddings al colocarlos en dispositivos distintos.

Con 36 capas, dos cabezas KV y dimensión por cabeza `2048 / 16 = 128`:

`KV por token = 2(K,V) × 36 × 2 × 128 × 2 B = 36 864 B = 36 KiB`.

| Contexto por sesión | KV FP16 por sesión | KV FP16 en 8 sesiones | Presupuesto total, 1 sesión | Presupuesto total, 8 sesiones |
|---:|---:|---:|---:|---:|
| 2 048 | 72 MiB | 576 MiB | 4 097 MiB | 4 601 MiB |
| 4 096 | 144 MiB | 1 152 MiB | 4 169 MiB | 5 177 MiB |
| 8 192 | 288 MiB | 2 304 MiB | 4 313 MiB | 6 329 MiB |

Presupuesto inicial = 3 449 MiB de archivo + 384 MiB de runtime + 192 MiB de activaciones + KV. Las reservas son hipótesis de planificación, constantes bajo el mismo microbatch. Se deben comprobar el mayor shard, la duplicación de pesos y la memoria de cada proceso. Aunque se habilite una sola sesión, `3 449 > 2 048` MiB prueba que el modelo entero excede el presupuesto de un worker.

## 3. Límite inicial por worker y costo

Con split `1,1,1`, un estimado inicial asigna 12 capas y 1 150 MiB por worker. KV por worker ≈ 12 KiB/token. Con 96 MiB de runtime y 48 MiB de activaciones, `max_ctx ≈ (2048−1150−96−48) × 1024/12 ≈ 64 341` tokens de presupuesto teórico. El modelo limita el contexto de una sesión a 32 768. El cálculo final usa la asignación y el tamaño virtual observados. Un uso de batch 8 implica ocho cachés independientes.

CAPEX de reposición COP 10 999 900. Inversión nueva COP 1 429 900 (UPS e instalación). OPEX de caja COP 3 189 995/año, incluidos COP 1 200 000 de energía, 1 440 000 de internet y 549 995 de mantenimiento. TCO de reposición a tres años COP 20 569 885. La depreciación informativa es COP 3 666 633/año. El detalle editable y las fuentes están en [costos.xlsx](costos.xlsx).
